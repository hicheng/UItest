# -*- coding: utf-8 -*-
"""小影圈Feed流视频详情页相关的测试用例."""
import time
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait



class TestPlay(TestCase):
    """
    小影圈Feed流视频详播放
    """

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_01_hot(self):
        """热门-Feed流视频播放"""
        sc.logger.info('热门-Feed流视频详情')

        sc.logger.info('点击小影圈')
        try:
            sc.driver.find_element_by_accessibility_id("xiaoyingquan_f").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("xiaoyingquan_n").click()

        sc.logger.info('点击"推荐"tab')
        sc.driver.find_element_by_name('推荐').click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('点击任意视频封面跳转热门feed流')
        el_video = sc.driver.find_element_by_xpath(
            '//*/XCUIElementTypeCollectionView//*/XCUIElementTypeOther[1]/XCUIElementTypeButton')
        el_video.click()

        sc.logger.info('等待完全跳转热门feed流')
        time.sleep(2)

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('播放一遍视频')
        time.sleep(180)

        sc.logger.info('点击评论按钮跳转-视频详情页')
        while True:
            try:
                el_comment = sc.driver.find_element_by_name("vivavideo comment")
                el_comment.click()
                break
            except NoSuchElementException:
                sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('等待完全跳转视频详情页')
        time.sleep(2)
        try:
            sc.driver.find_element_by_name('我知道了').click()
        except:
            sc.logger.info('不是首次进入该页面')

        sc.logger.info('上滑分页加载评论列表')
        sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('播放一遍视频')
        time.sleep(180)

        sc.logger.info('返回推荐feed列表')
        sc.driver.find_element_by_name("vivavideo video back n").click()

        sc.logger.info('返回推荐页面')
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

    def test_02_explore(self):
        """发现页-活动Feed流视频播放"""
        sc.logger.info('发现页-活动Feed流视频详情')

        sc.logger.info('点击"发现"tab')
        sc.driver.find_element_by_name('发现').click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('点击任意活动card跳转活动详情页面')
        el_card = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView//*/XCUIElementTypeCollectionView/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_card.click()

        sc.logger.info('等待完全展示当前活动视频列表')
        time.sleep(2)

        sc.logger.info('点击评论按钮跳转-视频详情页')
        while True:
            try:
                el_comment = sc.driver.find_element_by_name("vivavideo comment")
                el_comment.click()
                break
            except NoSuchElementException:
                sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('等待完全跳转视频详情页')
        time.sleep(2)

        sc.logger.info('上滑分页加载评论列表')
        sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('播放一遍视频')
        time.sleep(180)

        sc.logger.info('返回活动视频列表')
        sc.driver.find_element_by_name("vivavideo video back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('播放一遍视频')
        time.sleep(180)

        sc.logger.info('返回发现页面')
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动',i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

    def test_03_focus(self):
        """关注页视频播放"""
        sc.logger.info('关注页视频播放')

        sc.logger.info('点击"关注"tab')
        sc.driver.find_element_by_name('关注').click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('点击评论按钮跳转-视频详情页')
        while True:
            try:
                el_comment = sc.driver.find_element_by_name("vivavideo comment")
                el_comment.click()
                break
            except NoSuchElementException:
                sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('等待完全跳转视频详情页')
        time.sleep(3)

        sc.logger.info('上滑分页加载评论列表')
        sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('播放一遍视频')
        time.sleep(180)

        sc.logger.info('返回关注视频列表')
        sc.driver.find_element_by_name("vivavideo video back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('停留3分钟，播放一遍视频')
        time.sleep(180)

    def test_04_personal(self):
        """个人空间视频播放"""
        sc.logger.info('个人空间详情页')

        sc.logger.info('切换到"我"')
        btn_me = "//*/XCUIElementTypeTabBar/XCUIElementTypeButton[3]"
        sc.driver.find_element_by_xpath(btn_me).click()

        sc.logger.info('切换到作品tab')
        el_video = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '作品'")
        el_video.click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('停留3分钟，播放一遍视频')
        time.sleep(180)

        sc.logger.info('切换到关注tab')
        el_focus = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '关注'")
        el_focus.click()

        sc.logger.info('下拉刷新')
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.500)

        sc.logger.info('点击其他用户头像')
        el_avatar = sc.driver.find_element_by_xpath(
            '//*/XCUIElementTypeWindow[1]//*/XCUIElementTypeTable/*/XCUIElementTypeButton')
        el_avatar.click()

        sc.logger.info('等待完全跳转他人个人页')
        time.sleep(2)

        sc.logger.info('切换到作品tab')
        el_video = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '作品'")
        el_video.click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('停留3分钟，播放一遍视频')
        time.sleep(180)