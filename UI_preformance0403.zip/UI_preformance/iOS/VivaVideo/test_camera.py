# -*- coding: utf-8 -*-
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from appium.webdriver.common.touch_action import TouchAction
import time


class TestCamera(TestCase):
    # 获取屏幕尺寸
    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_normal_01_filter(self):
        """拍摄-滤镜下载"""
        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('点击高清拍摄')
        try:
            sc.driver.find_element_by_name("高清拍摄").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("拍摄").click()

        sc.logger.info('跳过订阅页面')
        try:
            sc.driver.find_element_by_name("跳过").click()
            try:
                sc.driver.find_element_by_name("高清拍摄").click()
            except NoSuchElementException:
                sc.driver.find_element_by_name("拍摄").click()
        except NoSuchElementException:
            sc.logger.info('已跳过订阅页面')

        sc.logger.info("授权小影访问相机和麦克风")
        try:
            sc.driver.find_element_by_name("好").click()  # 授权访问相机
            time.sleep(.500)
            sc.driver.find_element_by_name("好").click()  # 授权访问麦克风
        except NoSuchElementException:
            sc.logger.info("已授权")

        sc.logger.info('点击滤镜图标')
        sc.driver.find_element_by_name("vivavideo camera tool icon fil").click()

        sc.logger.info('滤镜下载-点击下载按钮')
        try:
            el_filter_download = sc.driver.find_element_by_accessibility_id("vivavideo_camera_tool_icon_download_nrm")
            el_filter_download.click()
            time.sleep(5)
        except NoSuchElementException:
            sc.logger.info('当前页面滤镜已下载')
        except TimeoutError as t:
            sc.logger.error('滤镜下载超时')

        sc.logger.info('下载更多')
        sc.driver.find_element_by_accessibility_id("vivavideo_camera_bg_filter_store").click()
        time.sleep(.500)

        sc.logger.info("使用滤镜")
        sc.driver.find_element_by_name('使用').click()

        sc.logger.info("向左滑动切换滤镜")
        start_x = self.width - self.width // 5
        start_bottom = self.height // 2

        for i in range(2):
            sc.logger.info('第 %d 次向左滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.6, 300)
            time.sleep(.300)

        sc.logger.info("点击屏幕消除滤镜控件")
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()

    def test_normal_02_settings(self):
        """拍摄-设置相关"""
        sc.logger.info('点击设置按钮')
        sc.driver.find_element_by_name("vivavideo camera tool icon set").click()

        sc.logger.info('闪光灯-开')
        try:
            sc.driver.find_element_by_name("vivavideo camera tool icon fla").click()
        except NoSuchElementException:
            sc.logger.info('当前为后置拍摄，无闪光灯选项')

        sc.logger.info('网格显示')
        sc.driver.find_element_by_name("vivavideo camera tool icon gri").click()

        sc.logger.info('倒计时')
        el_timer = sc.driver.find_element_by_name("vivavideo camera tool icon tim")
        for i in range(4):
            el_timer.click()

        sc.logger.info('退出设置选项')
        sc.driver.find_element_by_name("vivavideo camera tool icon set").click()

        sc.logger.info('前后置切换')
        sc.driver.find_element_by_name("vivavideo camera tool icon cha").click()

        sc.logger.info('视频尺寸,全屏切换到3:4')
        el_ful = sc.driver.find_element_by_name("vivavideo camera tool icon ful")
        el_ful.click()

        sc.logger.info('视频尺寸,3:4切换到1:1')
        el_fou = sc.driver.find_element_by_name("vivavideo camera tool icon fou")
        el_fou.click()

        sc.logger.info('视频尺寸,1:1切换到全屏')
        el_one = sc.driver.find_element_by_name("vivavideo camera tool icon one")
        el_one.click()

        sc.logger.info('切换拍摄模式:高清相机->自拍美颜')
        sc.driver.find_element_by_name("自拍美颜").click()
        time.sleep(.500)

        sc.logger.info('切换拍摄模式:自拍美颜->高清相机')
        sc.driver.find_element_by_name("高清相机").click()
        time.sleep(.500)

    def test_normal_03_shot(self):
        """拍摄-高清相机(1:1)"""
        # 点拍
        sc.logger.info('开始录制')
        el_capture = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeOther[4]/XCUIElementTypeOther/XCUIElementTypeOther[1]")
        el_capture.click()
        time.sleep(10)

        sc.logger.info('录制10s后点击录制按钮停止录制')
        el_capture.click()

        # 长按拍摄
        sc.logger.info('长按拍摄10s')
        actions = TouchAction(sc.driver)
        actions.long_press(el_capture, None, None, 10000).release().perform()

        sc.logger.info('点击确认按钮')
        sc.driver.find_element_by_name("vivavideo camera tool icon nex").click()

    def test_normal_04_text(self):
        """添加字幕"""

        sc.logger.info('点击"字幕"')
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("字幕").click()

        sc.logger.info('**************添加第一个字幕**************')
        sc.logger.info('点击添加按钮')
        sc.driver.find_element_by_name("vivavideo editor subtitle add").click()

        sc.logger.info('添加默认动态字幕')
        time.sleep(3)

        sc.logger.info('选择添加的"动态字幕"')
        sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther/XCUIElementTypeImage[1]").click()

        sc.logger.info('输入字幕')
        el_text_input = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeTextView' AND value == '请输入动态文字'")
        el_text_input.clear()
        el_text_input.send_keys("input text test")

        sc.logger.info('点击右侧"确认"按钮')
        sc.driver.find_element_by_name("确认").click()

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击左侧"暂停"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar paus").click()

        sc.logger.info('点击底部"确认"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar comp").click()

        sc.logger.info('**************添加第二个字幕**************')
        sc.logger.info('点击添加按钮')
        sc.driver.find_element_by_name("vivavideo editor subtitle add").click()

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击左侧"暂停"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar paus").click()

        sc.logger.info('点击底部"确认"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar comp").click()

        sc.logger.info('点击右上角保存并进入预览页')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

    def test_normal_05_sticker(self):
        """添加贴纸"""
        sc.logger.info('向左滑动')
        el_collage = sc.driver.find_element_by_name("画中画")
        coord_x = el_collage.location.get('x')
        coord_y = el_collage.location.get('y')
        sc.swipe_by_ratio(coord_x, coord_y, 'left', 0.7, 300)  # 从转场向左滑动

        sc.logger.info('点击"动画贴纸"')
        sc.driver.find_element_by_name("动画贴纸").click()

        sc.logger.info('**************添加多个贴纸**************')
        for i in range(3):
            sc.logger.info('第 d% 次添加贴纸', i)
            sc.driver.find_element_by_name("vivavideo tool sticker add n").click()

            sc.logger.info('选择一个"贴纸"添加')
            el_sticker = sc.driver.find_element_by_xpath(
                "//*/XCUIElementTypeCollectionView[2]/*/XCUIElementTypeOther/XCUIElementTypeImage")
            el_sticker.click()

            sc.logger.info('点击右上角保存')
            el_ok_btn = sc.driver.find_element_by_name("xiaoying com ok")
            el_ok_btn.click()
            time.sleep(1)

        sc.logger.info('点击右上角保存并返回到预览页')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('点击“保存/上传”按钮')
        sc.driver.find_element_by_name("保存/上传").click()

    def test_normal_06_export(self):
        """拍摄-导出"""
        sc.logger.info('点击屏幕消除软键盘')
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()

        sc.logger.info('点击“保存到相册”')
        sc.driver.find_element_by_name('保存到相册').click()
        time.sleep(.500)

        sc.logger.info('点击“清晰 480P”')
        try:
            sc.driver.find_element_by_name("清晰 480P").click()
            time.sleep(.500)
        except NoSuchElementException:
            sc.logger.info('该视频已导出，需要确认是否重新导出')
            sc.driver.find_element_by_name("重新导出").click()
            time.sleep(.500)
            sc.driver.find_element_by_name("清晰 480P").click()

        sc.logger.info('开始导出')
        try:
            WebDriverWait(sc.driver, 60).until(
                lambda V_exprot: V_exprot.find_element_by_name('我的工作室'))
            sc.logger.info('点击左上角返回按钮退回创作中心')
            time.sleep(.500)
            sc.driver.find_element_by_name("vivavideo com nav back n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("稍后再说").click()
            sc.logger.info('点击左上角返回按钮退回创作中心')
            time.sleep(.500)
            sc.driver.find_element_by_name("vivavideo com nav back n").click()
        except Exception as e:
            sc.logger.error('导出失败', e)
            return False