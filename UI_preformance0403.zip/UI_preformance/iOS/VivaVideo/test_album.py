# -*- coding: utf-8 -*-
from unittest import TestCase
from iOS import script_ultils as sc
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from appium.webdriver.common.touch_action import TouchAction


class TestAlbum(TestCase):
    # 获取屏幕尺寸
    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_album_01_swipe(self):
        """相册-所以素材展示"""
        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('点击视频剪辑')
        try:
            sc.driver.find_element_by_name("视频剪辑").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("剪辑").click()

        try:
            sc.driver.find_element_by_name("跳过").click()
            try:
                sc.driver.find_element_by_name("视频剪辑").click()
            except NoSuchElementException:
                sc.driver.find_element_by_name("剪辑").click()
        except NoSuchElementException:
            sc.logger.info('已跳过订阅页面')

        sc.logger.info("授权小影访问相册和媒体资料")
        try:
            sc.driver.find_element_by_name("好").click() #授权相册
            time.sleep(.500)
            sc.driver.find_element_by_name("好").click() #授权媒体资料库
        except NoSuchElementException:
            sc.logger.info("已授权")

        sc.logger.info('切换到图片')
        sc.driver.find_element_by_name("视频").click()
        sc.driver.find_element_by_name("图片").click()

        sc.logger.info('向上滑动多次展示素材')
        start_x = self.width // 2
        start_up = self.height // 2 + self.height // 10
        start_down = self.height // 3

        for i in range(5):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_up, 'up', 0.5, 300)
            time.sleep(.300)

        sc.logger.info('向下滑动多次返回顶部')
        for i in range(5):
            sc.logger.info('第 %d 次下滑动', i)
            sc.swipe_by_ratio(start_x, start_down, 'down', 0.5, 300)
            time.sleep(.300)

    def test_album_02_add(self):
        """添加图片素材"""
        sc.logger.info('图片操作-连续添加多张图片')
        el_imgs = sc.driver.find_elements_by_xpath("//*/XCUIElementTypeImage")
        i = 1
        while i < len(el_imgs):
            el_imgs[i].click()
            i = i + 1

        sc.logger.info('点击下一步进入预览页')
        sc.driver.find_element_by_name("下一步").click()

    def test_album_03_theme(self):
        """主题下载并应用"""
        sc.logger.info('点击“主题”按钮')
        sc.driver.find_element_by_name("主题").click()

        sc.logger.info('下载“主题”')
        try:
            el_theme_download = sc.driver.find_element_by_accessibility_id("vivavideo_tool_preview_download_n")
            el_theme_download.click()
        except NoSuchElementException:
            sc.logger.info('当前页面主题已全部下载')

        sc.logger.info('点击“下载更多”按钮')
        el_more = sc.driver.find_element_by_xpath(
            "//XCUIElementTypeImage[@name='vivavideo_tool_camera_store_n']")
        el_more.click()

        sc.logger.info('点击“下载”按钮')
        try:
            el_theme_download = sc.driver.find_element_by_name("vivavideo material download n")
            el_theme_download.click()
            time.sleep(10)
        except NoSuchElementException:
            sc.logger.info('当前页面主题已全部下载')

        sc.logger.info('点击“使用”按钮')
        try:
            el_template_use = sc.driver.find_element_by_name("使用")
            el_template_use.click()
        except NoSuchElementException:
            sc.logger.error('未找到已下载的素材')
            return False

    def test_album_04_filter(self):
        """滤镜下载并应用"""
        sc.logger.info('点击"滤镜"')
        time.sleep(1)
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("滤镜").click()

        sc.logger.info('选择一个"滤镜"')
        el_filter = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeImage")
        el_filter.click()

        sc.logger.info('切回"空滤镜"')
        el_empty = sc.driver.find_element_by_accessibility_id(
            "XiaoYingResource.bundle/vivavideo_tool_camera_none_n")
        el_empty.click()

        sc.logger.info('点击“多选”')
        sc.driver.find_element_by_name("多选").click()

        sc.logger.info('点击“全选”')
        sc.driver.find_element_by_name("全选").click()

        sc.logger.info('点击“随机”')
        sc.driver.find_element_by_name("随机").click()

        sc.logger.info('点击“确认”')
        sc.driver.find_element_by_name("确认").click()

        sc.logger.info('点击“右上角”保存')
        sc.driver.find_element_by_xpath(
            "//XCUIElementTypeButton[@name='xiaoying com ok']").click()

    def test_album_05_music(self):
        """配乐下载并应用"""
        sc.logger.info('点击"多段配乐"')
        time.sleep(.500)
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("多段配乐").click()

        sc.logger.info('**************添加第一段配乐**************')
        try:
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()
        except NoSuchElementException:
            sc.logger.info('当前视频位置已经添加过配乐，删除原配乐')
            sc.driver.find_element_by_name("vivavideo tool fx edit n").click()
            sc.logger.info('点击删除按钮')
            sc.driver.find_element_by_name("vivavideo tool subtitle delete").click()
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()

        sc.logger.info('点击下载按钮')
        try:
            sc.driver.find_element_by_name('vivavideo material download3 n').click()
            time.sleep(5)
        except NoSuchElementException:
            sc.driver.find_element_by_name('music select download n').click()
            time.sleep(5)
        except:
            sc.logger.info('当前页面无未下载配乐')


        sc.logger.info('点击第一首已下载音频试听')
        el_music_name = sc.driver.find_element_by_xpath("//*/XCUIElementTypeTable//*/XCUIElementTypeButton[2]")
        try:
            el_music_name.click()
        except NoSuchElementException:
            sc.logger.error('音频下载未完成，继续等待5s')
            time.sleep(5)
            el_music_name.click()

        sc.logger.info('点击“添加”按钮')
        sc.driver.find_element_by_name('添加').click()
        time.sleep(.500)

        sc.logger.info('3s后点击屏幕"暂停"播放')
        time.sleep(3)
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()

        sc.logger.info('确认添加的片段')
        sc.driver.find_element_by_name("vivavideo tool subtitle comple").click()

        sc.logger.info('点击左侧"播放按钮"')
        sc.driver.find_element_by_name("vivavideo editor framebar play").click()

        sc.logger.info('5s后点击屏幕"暂停"播放')
        time.sleep(3)
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()

        sc.logger.info('**************添加第二段配乐**************')
        time.sleep(.500)
        try:
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()
        except NoSuchElementException:
            sc.logger.info('当前视频位置已经添加过配乐，删除原配乐')
            sc.driver.find_element_by_name("vivavideo tool fx edit n").click()
            sc.logger.info('点击删除按钮')
            sc.driver.find_element_by_name("vivavideo tool subtitle delete").click()
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()

        sc.logger.info('点击第一首音频试听')
        el_music_name = sc.driver.find_element_by_xpath("//*/XCUIElementTypeTable//*/XCUIElementTypeButton[2]")
        el_music_name.click()

        sc.logger.info('点击“添加”按钮')
        sc.driver.find_element_by_name('添加').click()

        sc.logger.info('3s后点击屏幕"暂停"播放')
        time.sleep(3)
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()

        sc.logger.info('确认添加的第二段配乐')
        sc.driver.find_element_by_name("vivavideo tool subtitle comple").click()

        sc.logger.info('点击右上角确认按钮')
        sc.driver.find_element_by_name("xiaoying com ok").click()

    def test_album_06_transition(self):
        """转场下载并应用"""
        sc.logger.info('向左滑动')
        time.sleep(.500)
        el_collage = sc.driver.find_element_by_name("画中画")
        coord_x = el_collage.location.get('x')
        coord_y = el_collage.location.get('y')
        sc.swipe_by_ratio(coord_x, coord_y, 'left', 0.6,300)  # 从转场向左滑动

        sc.logger.info('点击"转场"')
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("转场").click()

        sc.logger.info('选择一个"转场"')
        el_tran = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeImage")
        el_tran.click()

        sc.logger.info('切回"无转场"')
        time.sleep(.500)
        el_empty = sc.driver.find_element_by_accessibility_id(
            "XiaoYingResource.bundle/vivavideo_tool_camera_none_n")
        el_empty.click()

        sc.logger.info('点击“多选”')
        sc.driver.find_element_by_name("多选").click()

        sc.logger.info('点击“全选”')
        sc.driver.find_element_by_name("全选").click()

        sc.logger.info('点击“随机”')
        sc.driver.find_element_by_name("随机").click()

        sc.logger.info('点击“确认”')
        sc.driver.find_element_by_name("确认").click()

        sc.logger.info('点击“右上角”保存')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('点击“保存/上传”按钮')
        sc.driver.find_element_by_name("保存/上传").click()

    def test_album_07_export(self):
        """拍摄-导出"""
        sc.logger.info('点击屏幕消除软键盘')
        time.sleep(.500)
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()

        sc.logger.info('点击“保存到相册”')
        sc.driver.find_element_by_name('保存到相册').click()
        time.sleep(.500)

        sc.logger.info('点击“清晰 480P”')
        try:
            sc.driver.find_element_by_name("清晰 480P").click()
            time.sleep(.500)
        except NoSuchElementException:
            sc.logger.info('该视频已导出，需要确认是否重新导出')
            sc.driver.find_element_by_name("重新导出").click()
            time.sleep(.500)
            sc.driver.find_element_by_name("清晰 480P").click()

        sc.logger.info('开始导出')
        try:
            WebDriverWait(sc.driver, 60).until(
                lambda V_exprot: V_exprot.find_element_by_name('我的工作室'))
            sc.logger.info('点击左上角返回按钮退回创作中心')
            time.sleep(.500)
            sc.driver.find_element_by_name("vivavideo com nav back n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("稍后再说").click()
            sc.logger.info('点击左上角返回按钮退回创作中心')
            time.sleep(.500)
            sc.driver.find_element_by_name("vivavideo com nav back n").click()
        except Exception as e:
            sc.logger.error('导出失败', e)
            return False