# -*- coding: utf-8 -*-
"""小影圈Feed流视频详情页相关的测试用例."""
import time
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait



class TestPlanet(TestCase):
    """
    小影圈Feed流视频详情页
    """

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_01_hot(self):
        """热门-Feed流视频详情"""
        sc.logger.info('热门-Feed流视频详情')

        sc.logger.info('点击小影圈')
        try:
            sc.driver.find_element_by_accessibility_id("xiaoyingquan_f").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("xiaoyingquan_n").click()

        sc.logger.info('点击"推荐"tab')
        sc.driver.find_element_by_name('推荐').click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('点击任意视频封面跳转热门feed流')
        el_video = sc.driver.find_element_by_xpath(
            '//*/XCUIElementTypeCollectionView//*/XCUIElementTypeOther[1]/XCUIElementTypeButton')
        el_video.click()

        sc.logger.info('等待完全跳转热门feed流')
        time.sleep(2)

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        #sc.logger.info('播放一遍视频')
        # time.sleep(180)
        #time.sleep(5)

        sc.logger.info('点击评论按钮跳转-视频详情页')
        while True:
            try:
                el_comment = sc.driver.find_element_by_name("vivavideo comment")
                el_comment.click()
                break
            except NoSuchElementException:
                sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('等待完全跳转视频详情页')
        time.sleep(2)
        try:
            sc.driver.find_element_by_name('我知道了').click()
        except:
            sc.logger.info('不是首次进入该页面')

        sc.logger.info('上滑分页加载评论列表')
        sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        #sc.logger.info('播放一遍视频')
        # time.sleep(180)
        #time.sleep(5)

        sc.logger.info('返回推荐feed列表')
        sc.driver.find_element_by_name("vivavideo video back n").click()

        sc.logger.info('返回推荐页面')
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

    def test_02_explore(self):
        """发现页-活动Feed流视频详情"""
        sc.logger.info('发现页-活动Feed流视频详情')

        sc.logger.info('点击"发现"tab')
        sc.driver.find_element_by_name('发现').click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('点击任意活动card跳转活动详情页面')
        el_card = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView//*/XCUIElementTypeCollectionView/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_card.click()

        sc.logger.info('等待完全展示当前活动视频列表')
        time.sleep(2)

        sc.logger.info('点击评论按钮跳转-视频详情页')
        while True:
            try:
                el_comment = sc.driver.find_element_by_name("vivavideo comment")
                el_comment.click()
                break
            except NoSuchElementException:
                sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('等待完全跳转视频详情页')
        time.sleep(2)

        sc.logger.info('上滑分页加载评论列表')
        sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        # sc.logger.info('播放一遍视频')
        # # time.sleep(180)
        # time.sleep(5)

        sc.logger.info('返回活动视频列表')
        sc.driver.find_element_by_name("vivavideo video back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        # sc.logger.info('播放一遍视频')
        # # time.sleep(180)
        # time.sleep(5)

        sc.logger.info('返回发现页面')
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动',i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

    def test_03_publish(self):
        """视频发布"""
        sc.logger.info('视频发布')

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('进入我的工作室')
        sc.driver.find_element_by_name("更多草稿").click()
        time.sleep(.500)

        sc.logger.info('保存并上传')
        el_publish = sc.driver.find_element_by_name("保存/上传")
        el_publish.click()
        time.sleep(.500)

        sc.logger.info('输入标题')
        try:
            el_title = sc.driver.find_element_by_xpath("//XCUIElementTypeStaticText[@name='请输入标题，你的作品记录了什么？']")
            el_title.clear()
            el_title.send_keys('input video title test')
            time.sleep(.500)
        except:
            sc.logger.info('标题已输入，跳过输入标题')

        sc.logger.info('发布')
        sc.driver.find_element_by_name("保存/上传").click()

        sc.logger.info('选择480P导出')
        try:
            sc.driver.find_element_by_name("清晰 480P").click()
        except:
            sc.logger.info('该视频已导出，直接上传')

        sc.logger.info('开始导出并上传')
        try:
            WebDriverWait(sc.driver, 60).until(
                lambda V_exprot: V_exprot.find_element_by_name('发现'))
        except Exception as e:
            sc.logger.error('发布失败', e)
            return False

    def test_04_focus(self):
        """关注页List View-话题详情页"""
        sc.logger.info('关注页List View-话题详情页')

        sc.logger.info('关闭分享列表')
        sc.driver.find_element_by_xpath(
            '//XCUIElementTypeButton[@name="vivavideo icon close nrm"]').click()

        sc.logger.info('点击"关注"tab')
        sc.driver.find_element_by_name('关注').click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('点击评论按钮跳转-视频详情页')
        while True:
            try:
                el_comment = sc.driver.find_element_by_name("vivavideo comment")
                el_comment.click()
                break
            except NoSuchElementException:
                sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        sc.logger.info('等待完全跳转视频详情页')
        time.sleep(3)

        sc.logger.info('上滑分页加载评论列表')
        sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)

        # sc.logger.info('播放一遍视频')
        # # time.sleep(180)
        # time.sleep(5)

        sc.logger.info('返回关注视频列表')
        sc.driver.find_element_by_name("vivavideo video back n").click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        # sc.logger.info('停留3分钟，播放一遍视频')
        # # time.sleep(180)
        # time.sleep(5)

    def test_05_personal(self):
        """个人空间详情页"""
        sc.logger.info('个人空间详情页')

        sc.logger.info('切换到"我"')
        btn_me = "//*/XCUIElementTypeTabBar/XCUIElementTypeButton[3]"
        sc.driver.find_element_by_xpath(btn_me).click()

        sc.logger.info('切换到作品tab')
        el_video = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '作品'")
        el_video.click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        # sc.logger.info('停留3分钟，播放一遍视频')
        # # time.sleep(180)
        # time.sleep(5)

        sc.logger.info('切换到粉丝tab')
        el_fan = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '粉丝'")
        el_fan.click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('切换到关注tab')
        el_focus = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '关注'")
        el_focus.click()

        sc.logger.info('下拉刷新')
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.500)

        sc.logger.info('点击其他用户头像')
        el_avatar = sc.driver.find_element_by_xpath(
            '//*/XCUIElementTypeWindow[1]//*/XCUIElementTypeTable/*/XCUIElementTypeButton')
        el_avatar.click()
        #assert el_avatar is not None

        sc.logger.info('等待完全跳转他人个人页')
        time.sleep(2)

        sc.logger.info('切换到作品tab')
        el_video = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '作品'")
        el_video.click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        # sc.logger.info('停留3分钟，播放一遍视频')
        # # time.sleep(180)
        # time.sleep(5)

        sc.logger.info('切换到粉丝tab')
        el_fan = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '粉丝'")
        el_fan.click()

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('切换到关注tab')
        el_focus = sc.driver.find_elements_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '关注'")

        for i in range(len(el_focus)):
            el_focus[i].click()
            try:
                sc.driver.find_element_by_name('取消').click()
            except NoSuchElementException:
                sc.logger.info('点击的不是"已关注/关注按钮"，切换到该用户的关注列表')

        sc.logger.info('向上滑动4次')
        for i in range(4):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('返回个人页面')
        sc.driver.find_element_by_name('vivavideo common back n').click()