# -*- coding: utf-8 -*-
"""python命令行参数处理"""
from appium import webdriver
import time
from iOS.start_appium import myserver

def iOS_driver(devicename, wdaport,port):
    desired_caps = {
        'platformName': 'iOS',
        'platformVersion': '',
        'deviceName': devicename,
        'bundleId': 'com.quvideo.XiaoYing',
        'app': '',
        'noReset': True,
        'automationName': 'XCUITest',
        'udid': 'auto',
        'xcodeOrgId': 'BMP99N9345',
        'xcodeSigningId': 'iPhone Developer',
        'autoLaunch': True,
        'wdaLocalPort': wdaport
    }

    remote_url = 'http://localhost:' + str(port) + '/wd/hub'
    time.sleep(5)
    drivers = webdriver.Remote(remote_url, desired_caps)
    return drivers


# device_list = [('6s2050', 8001)]
device_list = [('i62078', 8001),('6s2050', 8005)]
myserver().create_pools(len(device_list))
port_list = myserver().ports

for i in range(len(device_list)):
    dev = device_list[i][0]
    wdaport = device_list[i][1]
    port = port_list[i]
    print(dev, wdaport, port)
    time.sleep(10)
    driver = iOS_driver(dev, wdaport, port)

# # 多线程启动
# class appiumThread(threading.Thread):
#     def __init__(self, dev, wdaport):
#         threading.Thread.__init__(self)
#         self.thread_stop = False
#         self.dev = dev
#         self.port = wdaport
#     def run(self):
#         time.sleep(2)
#         driver = iOS_driver(self.dev,self.port)
#         return driver
#
# def create_threads(device_list):
#     thread_instances = []
#     if device_list != []:
#         for device,wdaport in device_list:
#             dev = device
#             wda_port = wdaport
#             print("deviceinfo:",dev,wdaport)
#             instance = appiumThread(dev,wda_port)
#             thread_instances.append(instance)
#         for instance in thread_instances:
#             instance.start()
#             time.sleep(5)
#
#         for instance in thread_instances:
#             instance.join()
#
# device_list = [('6s2050', 8001)]
# create_threads(device_list)