# # -*- coding: utf-8 -*-
#
# from appium import webdriver
# from iOS import Start_appium
# import os
#
#
# # class driver(object):
# #     def __init__(self, device):
# #         self.device = device
# #         self.desired_caps ={}
# #         self.desired_caps['platformName'] = 'Android'
# #         self.desired_caps['platformVersion'] = '5.0.2'
# #         self.desired_caps['udid'] = self.device
# #         self.desired_caps['deviceName'] = 'hermes'
# #         self.desired_caps['noReset'] = True
# #         self.desired_caps['appPackage'] = 'com.igola.travel'
# #         self.desired_caps['appActivity'] = 'com.igola.travel.ui.LaunchActivity'
# #         self.log = logger(date.today_report_path).getlog()
# #
# #     def connect(self, port):
# #         url = 'http://localhost:%s/wd/hub' % str(port)
# #         self.log.debug(url)
# #         try:
# #             global dr
# #             dr = webdriver.Remote(url, self.desired_caps)
# #             self.log.debug("启动接口为：%s,手机ID为：%s" % (str(port), self.device))
# #         except Exception:
# #             self.log.info("appium 启动失败")
# #             os.popen("taskkill /f /im adb.exe")
# #             raise
# #
# #     def getDriver(self):
# #         return dr
#
#
# #定义返回路径（绝对路径）
# PATH = lambda p: os.path.abspath(
#     os.path.join(os.path.dirname(__file__), p))
#
# def iOS_driver(device_name):
#     desired_caps = {
#         'platformName': 'iOS',
#         'platformVersion': '',
#         'deviceName': device_name,
#         'bundleId': 'com.quvideo.XiaoYing',
#         'app': '',
#         'noReset': True,
#         'automationName': 'XCUITest',
#         'udid': 'auto',
#         'xcodeOrgId': 'BMP99N9345',
#         'xcodeSigningId': 'iPhone Developer',
#         'autoLaunch': True,
#         'wdaLocalPort': '8001'
#     }
#
#     url = Start_appium.run()
#     print(url)
#
#     drivers = webdriver.Remote(url, desired_caps)
#
#     return drivers
#
# #devices = [('iPadmini4','b2478a26ab86ea345a014e49c44a8b06f9c3abd7'),('6s2050','5214866ccb9342f87f4c2aab093c25f7e252fd85')]
# # driver = iOS_driver(devices[1][0],devices[1][1])
# devices = ['iPadmini4','6s2050']
# driver = iOS_driver(devices[1])

#
# device_list = [('6s2050', 8001),('iPadmini4',8002)]
# print(len(device_list))
#
# port_list = [4723,4724]
#
# # for device, w_port in device_list:  # 根据已连接的设备数，启动多个appium
# #     dev = device
# #     wdaport = w_port
# #
# #     for port in port_list:
# #         print(dev,wdaport,port)
#
# for i in range(len(device_list)):
#     dev = device_list[i][0]
#     wdaport = device_list[i][1]
#     port = port_list[i]
#     print(dev,wdaport,port)
#
#
import  time
now_time = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))

print(now_time)