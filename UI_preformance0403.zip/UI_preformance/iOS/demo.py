import unittest
import time
import threading
import os
from iOS import script_ultils as sc, HTMLTestRunner
from iOS import start_appium as s


class runTest():
    def __init__(self):
        pass

    # def testcase(self):
    #     sc_path = os.path.join(os.getcwd(), "iOS/VivaVideo")
    #     suite = unittest.TestLoader().discover(sc_path, pattern="*.py", top_level_dir=None)
    #     return suite

    def run(self):
        sc_path = os.path.join(os.getcwd(), "iOS/VivaVideo")
        suite = unittest.TestLoader().discover(sc_path, pattern="*.py", top_level_dir=None)
        now_time = time.strftime("%Y%m%d%H%M", time.localtime(time.time()))
        report_path = sc.path_lists[2]
        filename = report_path + now_time + ".html"
        fp = open(filename, 'wb+')
        runner = HTMLTestRunner.HTMLTestRunner(
            stream=fp,
            title='VivaVideo UI 测试结果',
            description='详细测试报告',
            verbosity=2
        )
        runner.run(suite)  # 开始执行测试集
        s.kill_appium() # 退出appium服务

    def getDriver(self, driver):
        return driver

class myThread(threading.Thread):
    def __init__(self, dev, wdaport):
        threading.Thread.__init__(self)
        self.thread_stop = False
        self.dev = dev
        self.port = wdaport

    def run(self):
        if __name__ == '__main__':
            test = runTest()
            test.run()
            
            
if __name__ == '__main__':
    try:
        device_list = [('6s2050', 8001)]
        theading_pool = []
        for device in devices:   # 根据已连接的设备数，启动多个线程
            ms = myServer(device)
            config = ms.run()
            t = myThread(device, config)
            theading_pool.append(t)
        for t in theading_pool:
            t.start()
            time.sleep(5)
        for t in theading_pool:

            t.join()
    except:
        print("线程运行失败")
        raise

def create_threads(device_list):
#     thread_instances = []
#     if device_list != []:
#         for device,wdaport in device_list:
#             dev = device
#             wda_port = wdaport
#             print("deviceinfo:",dev,wdaport)
#             instance = appiumThread(dev,wda_port)
#             thread_instances.append(instance)
#         for instance in thread_instances:
#             instance.start()