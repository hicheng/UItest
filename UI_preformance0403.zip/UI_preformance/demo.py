# -*- coding: utf-8 -*-
"""多线程提交appium实例."""
import os
import random
import socket
# from appium import webdriver
import time
import subprocess
from concurrent.futures import ThreadPoolExecutor


def isOpen(ip, port):  # 判断端口是否被占用
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((ip, int(port)))
        s.shutdown(2)  # shutdown参数表示后续可否读写
        print('%d is used' % port)
        return True
    except Exception:
        print('%d is available' % port)
        return False


def getport():  # 获得端口号
    port = random.randint(4723, 4800)
    # 判断端口是否被占用
    while isOpen('127.0.0.1', port):
        port = random.randint(4723, 4800)
    return port


def srun(port):
    """启动appium服务.l"""

    print('start appium service')
    cmd_appium = 'appium -p ' + str(port)
    print(cmd_appium)
    try:
        # 启动appium服务
        subprocess.run(cmd_appium, shell=True)
    except Exception as msg:
        print('error message:', msg)
        raise


def kill_appium():
    cmd_kill = 'pkill node'
    os.system(cmd_kill)
    print('close appium service')


"""
def iOS_driver(spackage, splatform):
    desired_caps = {
        'appPackage': spackage,
        'appActivity': '.XiaoYingActivity',
        'platformName': splatform
    }
    port = getport()
    srun(port)
    print('port', port)
    remote_url = 'http://localhost:' + str(port) + '/wd/hub'
    print('remote_url', remote_url)

    time.sleep(10)
    drivers = webdriver.Remote(remote_url, desired_caps)
    return drivers


def android_driver(port, spackage, splatform):
    desired_caps = {
        'appPackage': spackage,
        'appActivity': '.XiaoYingActivity',
        'platformName': splatform
    }
    print('port', port)
    remote_url = 'http://localhost:' + str(port) + '/wd/hub'
    print('remote_url', remote_url)

    time.sleep(5)
    drivers = webdriver.Remote(remote_url, desired_caps)
    return drivers



# 多线程启动
class appiumThread(threading.Thread):
    def __init__(self, spackage, splatform):
        threading.Thread.__init__(self)
        self.thread_stop = False
        self.platform = splatform
        self.package = spackage

    def run(self):
        time.sleep(2)
        driver = iOS_driver(self.package, self.platform)
        return driver


def create_threads(device_list):
    thread_instances = []
    if device_list != []:
        for spackage, splatform in device_list:
            print("deviceinfo:", spackage, splatform)
            instance = appiumThread(spackage, splatform)
            thread_instances.append(instance)
        for instance in thread_instances:
            instance.start()
"""


# def ex_done(fn):
#     """线程结束后的回调函数，调试用."""
#     if fn.cancelled():
#         print('{}: canceled'.format(fn.arg))
#     elif fn.done():
#         error = fn.exception()
#         if error:
#             print('{}: error returned: {}'.format(
#                 fn.arg, error))
#         else:
#             result = fn.result()
#             print('{}: value returned: {}'.format(
#                 fn.arg, result))


executor = ThreadPoolExecutor(6)
ports = list()

def create_pools(device_list_length):
    for i in range(device_list_length):
        port = getport()
        ports.append(port)
        executor.submit(srun, port)
        # ex.arg = port
        # ex.add_done_callback(ex_done)
    return('running')


# device_list = [('com.quvideo.xiaoying', 'Android'), ('com.quvideo.xiaoying', 'Android')]

if __name__ == '__main__':
    # create_threads(device_list)
    # 简单提交5个的appium线程在后台运行，使用的是5个随机端口
    create_pools(5)

    # 下面的打印表示appium放在启动后，并没有阻塞主线程，主线程还能打印下面这些东西
    print('test!')
    print('端口列表: {}'.format(ports))
    for i in range(30):
        time.sleep(2)
        print(i)
