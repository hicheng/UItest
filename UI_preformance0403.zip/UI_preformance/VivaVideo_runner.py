#coding=utf-8
import os
import time
import unittest
from iOS import script_ultils as sc, HTMLTestRunner
from iOS.start_appium import myserver


def test_run():
    sc_path = os.path.join(os.getcwd(), "iOS/VivaVideo")
    suite = unittest.TestLoader().discover(sc_path, pattern="*.py", top_level_dir=None)
    now_time = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
    report_path = sc.path_lists[2]
    filename = report_path + now_time + ".html"
    fp = open(filename, 'wb+')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title='VivaVideo UI 测试结果',
        description='详细测试报告'
    )
    # for i in range(10):
    # sc.logger.info('第 %d 次测试开始', i)
    runner.run(suite)
    fp.close()


if __name__ == '__main__':
    print('start test')

    test_run()
    ms = myserver()
    ms.kill_appium()
    print('finish test')