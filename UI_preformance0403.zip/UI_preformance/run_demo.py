# -*- coding: utf-8 -*-
import unittest
import time
import threading
import os
from iOS import script_ultils as sc, HTMLTestRunner
from iOS.start_appium import myserver
from iOS.script_params import iOS_driver
from concurrent.futures import ThreadPoolExecutor


# class runTest():
#     def __init__(self):
#         pass
#
#     def testcase(self):
#         case_path = os.path.join(os.getcwd(), "VivaVideo")
#         suite = unittest.TestLoader().discover(case_path, pattern="*.py", top_level_dir=None)
#         return suite
#
#     def run(self,device):
#         now_time = time.strftime("%Y%m%d%H%M", time.localtime(time.time()))
#         report_path = sc.path_lists[2]
#         filename = report_path + now_time + ".html"
#         global fp
#         fp = open(filename, 'wb+')
#         runner = HTMLTestRunner.HTMLTestRunner(
#             stream=fp,
#             title='VivaVideo UI 测试结果',
#             description='设备 ' + device +' 的详细测试报告'
#         )
#         runner.run(self.testcase())
#         myserver().kill_appium()
#
#
# # 多线程执行测试用例
# class myThread(threading.Thread):
#     def __init__(self,dev):
#         threading.Thread.__init__(self)
#         self.dev = dev
#
#     def run(self):
#         test = runTest()
#         test.run(self.dev)
#         fp.close()  # 关闭测试报告文件


def testcase():
    sc_path = os.path.join(os.getcwd(), "VivaVideo")
    suite = unittest.TestLoader().discover(sc_path, pattern="*.py", top_level_dir=None)
    return suite


if __name__ == '__main__':
    try:
        theading_pool = []

        device_list = [('6s2050', 8001)]
        myserver().create_pools(len(device_list))
        time.sleep(5)
        port_list = myserver().ports

        for i in range(len(device_list)):
            dev = device_list[i][0]
            wdaport = device_list[i][1]
            port = port_list[i]
            print(dev, wdaport, port)

            iOS_driver(dev,wdaport,port)

        now_time = time.strftime("%Y%m%d%H%M", time.localtime(time.time()))
        report_path = sc.path_lists[2]
        filename = report_path + now_time + ".html"
        fp = open(filename, 'wb+')
        runner = HTMLTestRunner.HTMLTestRunner(
            stream=fp,
            title='VivaVideo UI 测试结果',
            description='详细测试报告',
            verbosity=2
        )
        # for i in range(10):
        # sc.logger.info('第 %d 次测试开始', i)
        runner.run(testcase())
        fp.close()

        #     instance = myThread(dev)
        #     theading_pool.append(instance)
        #
        # for instance in theading_pool:
        #     instance.start()
        #     time.sleep(5)
        # for instance in theading_pool:
        #     instance.join()
    except:
        print("线程运行失败")
        raise