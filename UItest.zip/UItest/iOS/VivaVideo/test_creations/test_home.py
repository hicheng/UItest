# -*- coding: utf-8 -*-
from unittest import TestCase
from iOS import script_ultils as sc
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait


class TestHome(TestCase):
    """首页测试类."""

    # 获取屏幕尺寸
    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_home(self):
        """首页"""
        fun_name = 'test_home'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('下拉刷新')
        start_x = self.width // 2
        start_bottom = self.height // 8
        sc.swipe_by_ratio(start_x, start_bottom, 'down', 0.5, 500)

        sc.logger.info('VIP订阅页面展示')
        sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther/XCUIElementTypeButton[1]").click()
        sc.capture_screen(fun_name, self.img_path)
        sc.driver.find_element_by_xpath("//XCUIElementTypeButton[@name='icon close n']").click()

        sc.logger.info('首页广告展示及刷新')
        sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther/XCUIElementTypeButton[2]").click()
        try:
            WebDriverWait(sc.driver, 15).until(
                lambda AD_refresh: AD_refresh.find_element_by_name("xiaoying shuffle change AD btn"))
            sc.capture_screen(fun_name, self.img_path)
            sc.driver.find_element_by_name("xiaoying shuffle change AD btn").click()
        except TimeoutError as t:
            sc.logger.error('广告加载超时',t)
            return False

        sc.logger.info('关闭广告')
        sc.driver.find_element_by_name("xiaoying shuffle ad close btn").click()