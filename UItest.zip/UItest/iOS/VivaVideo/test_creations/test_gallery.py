# -*- coding: utf-8 -*-
from unittest import TestCase
from iOS import script_ultils as sc
import time
from selenium.common.exceptions import NoSuchElementException

class TestGallery(TestCase):
    """相册测试类."""

    # 获取屏幕尺寸
    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_gallery_create(self):
        """创建草稿工程"""
        fun_name = 'test_gallery_create'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('点击视频剪辑')
        try:
            sc.driver.find_element_by_name("视频剪辑").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('添加视频')
        el_video = sc.driver.find_elements_by_accessibility_id("vivavideo_tool_gallery_audio_type_video")
        el_video[0].click()
        time.sleep(1)
        sc.driver.find_element_by_xpath("//XCUIElementTypeButton[@name='vivavideo tool gallery rotate ']").click()
        try:
            sc.driver.find_element_by_name('vivavideo tool gallery square').click()
        except NoSuchElementException:
            sc.logger.info('视频尺寸1:1，无此选项')
        sc.driver.find_element_by_name("vivavideo tool gallery trim d").click()
        sc.driver.find_element_by_xpath("//XCUIElementTypeButton[@name='添加 1']").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('切换到图片')
        sc.driver.find_element_by_name("视频").click()
        sc.driver.find_element_by_name("图片").click()

        sc.logger.info('图片操作-连续多选')
        el_imgs = sc.driver.find_elements_by_xpath("//*/XCUIElementTypeImage")
        i = 1
        if len(el_imgs) <= 6:
            while i < len(el_imgs):
                el_imgs[i].click()
                i = i + 1
        else:
            while i <= 6:
                el_imgs[i].click()
                i = i + 1
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('Storyboad操作')
        sc.driver.find_element_by_name("vivavideo tool gallery up n").click()
        el_del = sc.driver.find_elements_by_name("vivavideo edit video close n")
        for i in range(3):
            el_del[i].click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('预览页存草稿')
        sc.driver.find_element_by_name("下一步").click()
        sc.driver.find_element_by_name("存草稿").click()
        time.sleep(0.5)
        sc.capture_screen(fun_name, self.img_path)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()