# -*- coding: utf-8 -*-
"""镜头编辑相关操作的测试用例."""
import time
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from appium.webdriver.common.touch_action import TouchAction


class TestEdit(TestCase):
    """编辑操作测试类."""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    def setUp(self):
        sc.driver.launch_app()
        time.sleep(3)

    def tearDown(self):
        sc.driver.close_app()

    @staticmethod
    def test_edit_01_ahead():
        """创建草稿视频"""
        sc.logger.info('创建草稿视频')

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('点击视频剪辑')
        try:
            sc.driver.find_element_by_name("视频剪辑").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('添加视频')
        time.sleep(.500)
        el_video = sc.driver.find_element_by_accessibility_id("vivavideo_tool_gallery_audio_type_video")
        el_video.click()
        sc.driver.find_element_by_name("添加 0").click()

        sc.logger.info('添加图片')
        sc.driver.find_element_by_name("视频").click()
        sc.driver.find_element_by_name("图片").click()
        el_imgs = sc.driver.find_elements_by_xpath("//*/XCUIElementTypeImage")
        i = 1
        if len(el_imgs) <= 5:
            while i < len(el_imgs):
                el_imgs[i].click()
                i = i + 1
        else:
            while i <= 5:
                el_imgs[i].click()
                i = i + 1

        sc.logger.info('点击下一步，进入预览页')
        sc.driver.find_element_by_name("下一步").click()

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

    def test_edit_clip_02_video(self):
        """剪辑-镜头编辑-视频"""
        sc.logger.info('剪辑-镜头编辑-视频')
        fun_name = 'test_edit_clip'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('点击第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        time.sleep(0.5)
        sc.logger.info('点击"镜头编辑"')
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("镜头编辑").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('***************画面比例***************')
        time.sleep(.500)
        sc.driver.find_element_by_name('画面比例').click()

        sc.logger.info('切换到"1:1"')
        sc.driver.find_element_by_accessibility_id('vivavideo_edit_icon_proportion_1_1').click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"确认"，保存修改')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('***************修剪***************')
        time.sleep(.500)
        sc.logger.info('点击"修剪"')
        try:
            sc.driver.find_element_by_name("修剪").click()
            sc.logger.info('点击"确认按钮"，保存修剪')
            sc.driver.find_element_by_name("xiaoying com ok").click()
        except NoSuchElementException:
            sc.logger.info('当前镜头为图片，不支持"修剪"')

        sc.logger.info('***************分割***************')
        try:
            sc.driver.find_element_by_name("分割").click()
            sc.logger.info('点击"确认"，保存分割')
            sc.driver.find_element_by_name("xiaoying com ok").click()
        except NoSuchElementException:
            sc.logger.info("当前镜头为图片，不支持'分割'")

        sc.logger.info('***************复制***************')
        sc.driver.find_element_by_name("复制").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('***************变速***************')
        try:
            sc.driver.find_element_by_name("变速").click()
            sc.logger.info('勾选"运用于全部视频镜头"')
            sc.driver.find_element_by_name("运用于全部视频镜头").click()

            sc.logger.info('勾选"保持音调不变"')
            sc.driver.find_element_by_name("保持音调不变").click()
            sc.capture_screen(fun_name, self.img_path)

            sc.logger.info('点击"确认按钮"，保存变速')
            sc.driver.find_element_by_name("xiaoying com ok").click()
        except NoSuchElementException:
            sc.logger.info("当前镜头为图片，不支持'变速'")

        sc.logger.info('***************调节***************')
        el_adjust = sc.driver.find_element_by_name("调节")
        el_adjust.click()

        sc.logger.info('点击"取消"，取消调节')
        sc.driver.find_element_by_name("xiaoying com cancel").click()

        sc.logger.info('向左滑动')
        time.sleep(0.5)
        coord_x = el_adjust.location.get('x')
        coord_y = el_adjust.location.get('y')
        sc.swipe_by_ratio(coord_x, coord_y, 'left', 0.6, 500)  # 从调节按钮向左滑动

        sc.logger.info('***************静音***************')
        try:
            sc.driver.find_element_by_name("静音").click()
        except NoSuchElementException:
            sc.logger.info("当前镜头为图片，不支持'静音'")

        sc.logger.info('***************镜头倒放***************')
        try:
            el_reverse = sc.driver.find_element_by_name("镜头倒放")
            el_reverse.click()
        except:
            sc.logger.info('向左滑动')
            time.sleep(0.5)
            sc.swipe_by_ratio(coord_x, coord_y, 'left', 0.6, 500)  # 从调节按钮向左滑动
            el_reverse = sc.driver.find_element_by_name("镜头倒放")
            el_reverse.click()
        sc.capture_screen(fun_name, self.img_path)
        time.sleep(20)

        sc.logger.info('***************模糊背景***************')
        el_bg = "XiaoYingResource.bundle/vivavideo_tool_clipedit_bgimageoff_n"
        try:
            sc.driver.find_element_by_accessibility_id(el_bg).click()
        except:
            sc.swipe_by_ratio(coord_x, coord_y, 'left', 0.6, 500)  # 从调节按钮向左滑动
            sc.driver.find_element_by_accessibility_id(el_bg).click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('保存编辑')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('存草稿并返回创作页首页')
        sc.driver.find_element_by_name("存草稿").click()
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_clip_03_img(self):
        """剪辑-镜头编辑-图片"""
        sc.logger.info('剪辑-镜头编辑-图片')
        fun_name = 'test_edit_clip_img'

        sc.logger.info('点击视频剪辑')
        try:
            sc.driver.find_element_by_name("视频剪辑").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('切换到图片')
        sc.driver.find_element_by_name("视频").click()
        sc.driver.find_element_by_name("图片").click()

        sc.logger.info('图片操作-连续多选')
        el_imgs = sc.driver.find_elements_by_xpath("//*/XCUIElementTypeImage")
        i = 1
        if len(el_imgs) <= 5:
            while i < len(el_imgs):
                el_imgs[i].click()
                i = i + 1
        else:
            while i <= 5:
                el_imgs[i].click()
                i = i + 1

        sc.logger.info('点击下一步，进入预览页')
        sc.driver.find_element_by_name("下一步").click()
        sc.capture_screen(fun_name, self.img_path)

        time.sleep(0.5)
        sc.logger.info('点击"镜头编辑"')
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("镜头编辑").click()

        sc.logger.info('***************画面比例***************')
        time.sleep(1)
        sc.logger.info('点击"画面比例"')
        sc.driver.find_element_by_name('画面比例').click()

        sc.logger.info('切换到"1:1"')
        time.sleep(.500)
        sc.driver.find_element_by_accessibility_id('vivavideo_edit_icon_proportion_1_1').click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('切换到"背景颜色"')
        sc.driver.find_element_by_name("vivavideo edit icon color n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('切换到"背景图片"')
        sc.driver.find_element_by_name("vivavideo edit icon background").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('选择一个"背景图片"')
        el_bg = "//*/XCUIElementTypeOther[4]//*/XCUIElementTypeOther/XCUIElementTypeImage"
        sc.driver.find_element_by_xpath(el_bg).click()

        sc.logger.info('fit屏幕')
        sc.driver.find_element_by_name("vivavideo edit ratio icon fiti").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"x"，取消修改')
        sc.driver.find_element_by_name("vivavideo editor common cancel").click()
        sc.driver.find_element_by_name("确认").click()
        time.sleep(1)

        sc.logger.info('***************图片时长***************')
        sc.logger.info('点击"图片时长"')
        try:
            sc.driver.find_element_by_name("图片时长").click()
            sc.logger.info('点击"确认"，保存图片时长设置')
            sc.driver.find_element_by_name("xiaoying com ok").click()
        except NoSuchElementException:
            sc.logger.info("当前镜头为视频，不支持'图片时长'")

        sc.logger.info('保存编辑')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('存草稿')
        sc.driver.find_element_by_name("存草稿").click()
        time.sleep(.500)

        sc.logger.info('删除草稿')
        el_del_draft = sc.driver.find_element_by_name("vivavideo tool studio delete n")
        el_del_draft.click()
        sc.driver.find_element_by_name("是").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('返回创作页首页')
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_clip_04_other(self):
        """剪辑-镜头编辑-其他编辑"""
        sc.logger.info('剪辑-镜头编辑-其他编辑')
        fun_name = 'test_clip_edit_other'

        sc.logger.info('点击第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        time.sleep(0.5)
        sc.logger.info('点击"镜头编辑"')
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("镜头编辑").click()

        sc.logger.info('删除任一镜头')
        el_clip_del = sc.driver.find_element_by_name("vivavideo edit video close n")
        el_clip_del.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('确认"删除"')
        sc.driver.find_element_by_name("确认").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('多选镜头')
        sc.driver.find_element_by_name("vivavideo tool gallery up n").click()
        time.sleep(0.5)
        sc.driver.find_element_by_name("多选").click()

        sc.logger.info('全选')
        sc.driver.find_element_by_name("全选").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"镜头动态效果"按钮')
        sc.driver.find_element_by_name("vivavideo tool clipedit bgimag").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('多镜头-打开镜头动态效果')
        sc.driver.find_element_by_name("打开镜头动态效果").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('多镜头-关闭镜头动态效果')
        sc.driver.find_element_by_name("vivavideo tool clipedit bgimag").click()
        sc.driver.find_element_by_name("关闭镜头动态效果").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"镜头原音"开关')
        sc.driver.find_element_by_name("vivavideo tool clipedit sound2").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('打开镜头原音')
        sc.driver.find_element_by_name("打开 镜头原音 ").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('关闭镜头原音')
        sc.driver.find_element_by_name("vivavideo tool clipedit sound2").click()
        sc.driver.find_element_by_name("关闭 镜头原音").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"删除"按钮')
        sc.driver.find_element_by_name("vivavideo tool clipedit delete").click()

        sc.logger.info('取消"删除"')
        sc.driver.find_element_by_xpath("(//XCUIElementTypeButton[@name='取消'])[1]").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('保存所有改动')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('点击"添加"按钮')
        start_x = self.width // 2
        start_bottom = self.height - self.height // 10
        sc.driver.find_element_by_name("vivavideo tool gallery up n").click()
        time.sleep(0.5)
        while True:
            try:
                sc.logger.info('点击添加镜头按钮')
                sc.driver.find_element_by_name("vivavideo tool clipedit add n").click()
                sc.capture_screen(fun_name, self.img_path)
                break
            except NoSuchElementException:
                sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.6, 500)

        sc.logger.info('添加视频')
        el_video = sc.driver.find_element_by_accessibility_id("vivavideo_tool_gallery_audio_type_video")
        el_video.click()
        sc.driver.find_element_by_name("添加 0").click()

        sc.logger.info('点击右上角拍摄按钮')
        sc.driver.find_element_by_name("vivavideo gallery create captu").click()
        time.sleep(.500)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('开始录制')
        el_capture = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther[1]")
        el_capture.click()
        time.sleep(5)

        sc.logger.info('录制5s后点击录制按钮停止录制')
        el_capture.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"确认"按钮')
        sc.driver.find_element_by_name("vivavideo camera tool icon nex").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"下一步"')
        sc.driver.find_element_by_name("下一步").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('保存编辑')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('存草稿并返回创作页首页')
        sc.driver.find_element_by_name("存草稿").click()
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_collage(self):
        """剪辑-画中画"""
        sc.logger.info('剪辑-画中画')
        fun_name = 'test_edit_collage'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('点击首页第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        sc.logger.info('点击"画中画"')
        time.sleep(0.5)
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("画中画").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('**************添加普通图片**************')
        sc.logger.info('点击添加按钮')
        sc.driver.find_element_by_name("vivavideo editor collage add n").click()

        sc.logger.info('选择一个"图片"添加')
        time.sleep(1)
        el_comm = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]//*/XCUIElementTypeOther[4]//*/XCUIElementTypeCollectionView[1]/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_comm.click()

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击左侧"暂停"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar paus").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击底部"确认"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar comp").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('**************添加gif图片图片**************')
        sc.logger.info('点击添加按钮')
        sc.driver.find_element_by_name("vivavideo editor collage add n").click()

        sc.logger.info('切换到GIF')
        sc.driver.find_element_by_name("GIF").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('搜索GIF图片')
        el_search = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeTextField' AND value == '搜索Gif'")
        el_search.clear()
        el_search.send_keys('a')
        sc.driver.find_element_by_accessibility_id("Search").click()
        time.sleep(5)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('检查GIF图片下载是否成功')
        try:
            WebDriverWait(sc.driver, 60).until(
                lambda gif: gif.find_element_by_accessibility_id("vivavideo_tool_collage_download_n"))
            el_gif_download = sc.driver.find_element_by_accessibility_id("vivavideo_tool_collage_download_n")
            el_gif_download.click()
            time.sleep(10)
            sc.capture_screen(fun_name, self.img_path)
        except Exception as e:
            sc.logger.error('GIF图片加载异常', e)
            return False

        sc.logger.info('使用该下载的GIF图片')
        el_gif_use = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView[2]/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_gif_use.click()
        time.sleep(5)

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击左侧"暂停"按钮')
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo editor framebar paus").click()

        sc.logger.info('点击底部"确认"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar comp").click()

        sc.logger.info('点击右上角确认按钮')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('返回创作中心主界面')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_filter(self):
        """剪辑-滤镜"""
        sc.logger.info('剪辑-滤镜')
        fun_name = 'test_edit_filter'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('进入我的工作室')
        sc.driver.find_element_by_name("更多草稿").click()
        time.sleep(0.5)

        sc.logger.info('点击一个草稿工程封面')
        el_draft = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView//*/XCUIElementTypeImage[1]")
        el_draft.click()

        time.sleep(0.5)
        sc.logger.info('点击"滤镜"')
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("滤镜").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('选择一个"滤镜"')
        el_filter = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeImage")
        el_filter.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('切回"空滤镜"')
        time.sleep(1)
        el_empty = sc.driver.find_element_by_accessibility_id(
            "XiaoYingResource.bundle/vivavideo_tool_camera_none_n")
        el_empty.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“下载更多”按钮')
        time.sleep(1)
        el_more = sc.driver.find_element_by_accessibility_id(
            "XiaoYingResource.bundle/vivavideo_tool_camera_store_n")
        el_more.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“左上角”返回预览页')
        time.sleep(0.5)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

        sc.logger.info('点击“多选”')
        sc.driver.find_element_by_name("多选").click()

        sc.logger.info('点击“全选”')
        sc.driver.find_element_by_name("全选").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“随机”')
        sc.driver.find_element_by_name("随机").click()

        sc.logger.info('点击“确认”')
        sc.driver.find_element_by_name("确认").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“右上角”保存')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('存草稿并返回创作页首页')
        sc.driver.find_element_by_name("存草稿").click()
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_fx(self):
        """剪辑-特效"""
        sc.logger.info('剪辑-特效')
        fun_name = 'test_edit_fx'

        sc.logger.info('点击首页第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        sc.logger.info('点击"剪辑"')
        time.sleep(0.5)
        sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('向左滑动')
        start_x = self.width - self.width // 10
        start_bottom = self.height - self.height // 5
        for i in range(2):
           sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.8, 500)

        sc.logger.info('点击"特效"')
        sc.driver.find_element_by_name("特效").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"添加"按钮')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo tool fx add n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('选择一个"特效"下载')
        try:
            el_fx_down = sc.driver.find_element_by_accessibility_id("vivavideo_tool_camera_download_n")
            el_fx_down.click()
        except NoSuchElementException:
            sc.logger.info('当前页面"特效"已全部下载')

        sc.logger.info('选择一个"特效"使用')
        try:
            WebDriverWait(sc.driver, 20).until(
                lambda el_fx_use: el_fx_use.find_element_by_xpath(
                    "//*/XCUIElementTypeOther[5]//*/XCUIElementTypeOther/XCUIElementTypeImage"))
            el_fx = sc.driver.find_element_by_xpath(
                "//*/XCUIElementTypeOther[5]//*/XCUIElementTypeOther/XCUIElementTypeImage")
            el_fx.click()
            sc.capture_screen(fun_name, self.img_path)
        except Exception as e:
            sc.logger.info('下载"贴纸"失败', e)
            return False

        sc.logger.info('点击下载更多')
        sc.driver.find_element_by_name("vivavideo tool subtitle store ").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('返回贴纸添加页面')
        sc.driver.find_element_by_name('vivavideo com nav back n').click()

        sc.logger.info('点击右上角保存')
        el_ok_btn = sc.driver.find_element_by_name("xiaoying com ok")
        for i in range(2):
            el_ok_btn.click()
            sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('返回创作中心主界面')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_music(self):
        """剪辑-多段配乐"""
        sc.logger.info('剪辑-多段配乐')
        fun_name = 'test_edit_music'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('点击首页第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        sc.logger.info('点击"多段配乐"')
        time.sleep(0.5)
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("多段配乐").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('**************添加第一段配乐**************')
        try:
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()
        except NoSuchElementException:
            sc.logger.info('当前视频位置已经添加过配乐，删除原配乐')
            sc.driver.find_element_by_name("vivavideo tool fx edit n").click()
            sc.logger.info('点击删除按钮')
            sc.driver.find_element_by_name("vivavideo tool subtitle delete").click()
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()

        sc.logger.info('点击下载按钮')
        try:
            sc.driver.find_element_by_name('vivavideo material download3 n').click()
        except NoSuchElementException:
            sc.driver.find_element_by_name('music select download n').click()
        sc.capture_screen(fun_name, self.img_path)
        time.sleep(10)

        sc.logger.info('点击第一首已下载音频试听')
        el_music_name = sc.driver.find_element_by_xpath("//*/XCUIElementTypeTable//*/XCUIElementTypeButton[2]")
        try:
            el_music_name.click()
        except NoSuchElementException:
            sc.logger.error('音频下载未完成，继续等待5s')
            time.sleep(5)
            el_music_name.click()

        sc.logger.info('点击“添加”按钮')
        sc.driver.find_element_by_name('添加').click()

        sc.logger.info('5s后点击屏幕"暂停"播放')
        time.sleep(5)
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('确认添加的片段')
        sc.driver.find_element_by_name("vivavideo tool subtitle comple").click()

        sc.logger.info('点击左侧"播放按钮"')
        sc.driver.find_element_by_name("vivavideo editor framebar play").click()

        sc.logger.info('5s后点击屏幕"暂停"播放')
        time.sleep(5)
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('**************添加第二段配乐**************')
        try:
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()
        except NoSuchElementException:
            sc.logger.info('当前视频位置已经添加过配乐，删除原配乐')
            sc.driver.find_element_by_name("vivavideo tool fx edit n").click()
            sc.logger.info('点击删除按钮')
            sc.driver.find_element_by_name("vivavideo tool subtitle delete").click()
            sc.logger.info('点击添加按钮')
            sc.driver.find_element_by_name("vivavideo tool multimusic add ").click()

        sc.logger.info('点击第一首音频试听')
        el_music_name = sc.driver.find_element_by_xpath("//*/XCUIElementTypeTable//*/XCUIElementTypeButton[2]")
        el_music_name.click()

        sc.logger.info('点击“添加”按钮')
        sc.driver.find_element_by_name('添加').click()

        sc.logger.info('3s后点击屏幕"暂停"播放')
        time.sleep(3)
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()

        sc.logger.info('确认添加的第二段配乐')
        sc.driver.find_element_by_name("vivavideo tool subtitle comple").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击右上角确认按钮')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('返回创作中心主界面')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_sound(self):
        """剪辑-配音和音效"""
        sc.logger.info('剪辑-配音和音效')
        fun_name = 'test_edit_sound'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('点击首页第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        sc.logger.info('点击"剪辑"')
        time.sleep(0.5)
        sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('向左滑动')
        start_x = self.width - self.width // 10
        start_bottom = self.height - self.height // 5
        sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.8, 500)

        sc.logger.info('点击"配音和音效"')
        try:
            sc.driver.find_element_by_name("配音和音效").click()
        except NoSuchElementException:
            sc.logger.info('未找到"配音和音效"按钮，再向左滑动')
            sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.8, 500)
            sc.driver.find_element_by_name("配音和音效").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击右侧预置"配音"图标')
        sc.driver.find_element_by_name("vivavideo tool sound list n").click()

        sc.logger.info('选择一个"音频"试听')
        el_sound_name = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeTable/*/XCUIElementTypeButton[2]")
        el_sound_name.click()

        sc.logger.info('添加')
        sc.driver.find_element_by_name("添加").click()

        sc.logger.info('剪辑-配音-录音')
        try:
            WebDriverWait(sc.driver,20).until(
                lambda el_record:el_record.find_element_by_name("vivavideo tool sound start n"))
            el_record = sc.driver.find_element_by_name("vivavideo tool sound start n")

            sc.logger.info("授权小影访问麦克风")
            try:
                el_record.click()
                sc.driver.find_element_by_name("好").click()  # 授权访问麦克风
                time.sleep(1)
            except NoSuchElementException:
                sc.logger.info("已授权")

            sc.logger.info('长按录制5s音频')
            actions = TouchAction(sc.driver)
            actions.long_press(el_record, None, None, 5000).release().perform()
            sc.capture_screen(fun_name, self.img_path)
        except NoSuchElementException:
            sc.logger.info('添加的配音音频时长超出20s，可选择时长小的音频或者修改等待时长')

        sc.logger.info('点击“右上角”保存')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('存草稿并返回创作页首页')
        sc.driver.find_element_by_name("存草稿").click()
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_sticker(self):
        """剪辑-动画贴纸"""
        sc.logger.info('剪辑-动画贴纸')
        fun_name = 'test_edit_sticker'

        sc.logger.info('点击首页第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        sc.logger.info('点击"剪辑"')
        time.sleep(0.5)
        sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('向左滑动')
        el_collage = sc.driver.find_element_by_name("画中画")
        coord_x = el_collage.location.get('x')
        coord_y = el_collage.location.get('y')
        sc.swipe_by_ratio(coord_x, coord_y, 'left', 0.6, 500)  # 从画中画向左滑动

        sc.logger.info('点击"动画贴纸"')
        sc.driver.find_element_by_name("动画贴纸").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"添加"按钮')
        sc.driver.find_element_by_name("vivavideo tool sticker add n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('选择一个"贴纸"添加')
        el_sticker = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView[2]/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_sticker.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('镜像"贴纸"')
        sc.driver.find_element_by_accessibility_id(
            "XiaoYingResource.bundle/vivavideo_tool_subtitle_flip_n").click()

        sc.logger.info('切换"贴纸"分类')
        el_sticker_type = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView[1]/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_sticker_type.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('下载该分类"贴纸"')
        try:
            sc.driver.find_element_by_name("免费下载").click()
        except NoSuchElementException:
            sc.logger.info('该分类"贴纸"已下载')

        sc.logger.info('点击GIF图标')
        sc.driver.find_element_by_name("GIF").click()
        time.sleep(3)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('返回贴纸添加页面')
        sc.driver.find_element_by_name('vivavideo com nav back n').click()

        sc.logger.info('点击下载更多')
        sc.driver.find_element_by_name("xiaoying itembar down more").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('返回贴纸添加页面')
        sc.driver.find_element_by_name('vivavideo com nav back n').click()

        sc.logger.info('点击右上角保存')
        el_ok_btn = sc.driver.find_element_by_name("xiaoying com ok")
        for i in range(2):
            el_ok_btn.click()
            sc.capture_screen(fun_name,self.img_path)

        sc.logger.info('点击“存草稿”按钮')
        time.sleep(.500)
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('返回创作中心主界面')
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_text(self):
        """剪辑-字幕"""
        sc.logger.info('剪辑-字幕')
        fun_name = 'test_edit_text'

        sc.logger.info('点击创作中心主按钮')
        time.sleep(1)
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('点击首页第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        sc.logger.info('点击"字幕"')
        time.sleep(0.5)
        sc.driver.find_element_by_name("剪辑").click()
        sc.driver.find_element_by_name("字幕").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('**************添加第一个字幕**************')
        sc.logger.info('点击添加按钮')
        sc.driver.find_element_by_name("vivavideo editor subtitle add").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('添加默认动态字幕')
        time.sleep(3)

        sc.logger.info('选择添加的"动态字幕"')
        sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther/XCUIElementTypeImage[1]").click()

        sc.logger.info('输入字幕')
        el_text_input = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeTextView' AND value == '请输入动态文字'")
        el_text_input.clear()
        el_text_input.send_keys("input text test")
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击右侧"确认"按钮')
        sc.driver.find_element_by_name("确认").click()

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击左侧"暂停"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar paus").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击底部"确认"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar comp").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('**************添加第二个字幕**************')
        sc.logger.info('点击添加按钮')
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo editor subtitle add").click()

        sc.logger.info('切换到普通字幕')
        sc.driver.find_element_by_name("xiaoying caption bar text n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('选择一个普通字幕并添加')
        el_com_text = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView[2]/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_com_text.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('切换到字体页面')
        sc.driver.find_element_by_name("xiaoying caption bar aa n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"下载"按钮')
        try:
            el_text_down = sc.driver.find_element_by_accessibility_id(
                "vivavideo_camera_tool_icon_sticker_download_nrm")
            el_text_down.click()
        except NoSuchElementException:
            sc.logger.info('当前页面已无为下载字体')

        sc.logger.info('切换到描边页面')
        sc.driver.find_element_by_name("xiaoying caption bar font n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('切换到字体设置页面')
        sc.driver.find_element_by_name("xiaoying caption bar set n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击阴影开关')
        sc.driver.find_element_by_xpath("//*/XCUIElementTypeSwitch[1]").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击字幕动画开关')
        sc.driver.find_element_by_xpath("//*/XCUIElementTypeSwitch[2]").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('左对齐')
        sc.driver.find_element_by_name("xiaoying caption bar set btn l").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('居中对齐')
        sc.driver.find_element_by_name("xiaoying caption bar set btn c").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('右对齐')
        sc.driver.find_element_by_name("xiaoying caption bar set btn r").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击左侧"暂停"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar paus").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击底部"确认"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar comp").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('返回创作中心主界面')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_edit_transition(self):
        """剪辑-转场"""
        sc.logger.info('剪辑-转场')
        fun_name = 'test_edit_transition'

        sc.logger.info('点击首页第一个草稿封面')
        el_draft = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[2]/*/XCUIElementTypeButton")
        el_draft.click()

        sc.logger.info('点击"剪辑"')
        time.sleep(0.5)
        sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('向左滑动')
        start_x = self.width - self.width // 10
        start_bottom = self.height - self.height // 5
        sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.8, 500)

        sc.logger.info('点击"转场"')
        sc.driver.find_element_by_name("转场").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('选择一个"转场"')
        el_tran = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeImage")
        el_tran.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“多选”')
        sc.driver.find_element_by_name("多选").click()

        sc.logger.info('点击“全选”')
        sc.driver.find_element_by_name("全选").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“随机”')
        sc.driver.find_element_by_name("随机").click()

        sc.logger.info('点击“确认”')
        sc.driver.find_element_by_name("确认").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“右上角”保存')
        sc.driver.find_element_by_name("xiaoying com ok").click()

        sc.logger.info('存草稿并返回创作页首页')
        sc.driver.find_element_by_name("存草稿").click()
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()


