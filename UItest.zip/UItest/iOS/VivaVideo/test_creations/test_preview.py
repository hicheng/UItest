# -*- coding: utf-8 -*-
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
import time


class TestPreview(TestCase):
    """预览页测试类."""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_preview(self):
        """预览页测试"""
        sc.logger.info('预览页测试')
        fun_name = 'test_preview'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        sc.logger.info('点击视频剪辑')
        try:
            sc.driver.find_element_by_name("视频剪辑").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("剪辑").click()

        sc.logger.info('添加视频')
        el_video = sc.driver.find_elements_by_accessibility_id("vivavideo_tool_gallery_audio_type_video")
        el_video[0].click()
        time.sleep(1)
        sc.driver.find_element_by_xpath("//XCUIElementTypeButton[@name='添加 0']").click()

        sc.logger.info('切换到图片')
        sc.driver.find_element_by_name("视频").click()
        sc.driver.find_element_by_name("图片").click()

        sc.logger.info('添加图片')
        el_imgs = sc.driver.find_elements_by_xpath("//*/XCUIElementTypeImage")
        el_imgs[1].click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击下一步，进入预览页')
        sc.driver.find_element_by_name("下一步").click()
        sc.capture_screen(fun_name,self.img_path)

        sc.logger.info('点击“主题”按钮')
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo tool preview filter ").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('下载“主题”')
        try:
            el_theme_download = sc.driver.find_element_by_accessibility_id("vivavideo_tool_preview_download_n")
            el_theme_download.click()
        except NoSuchElementException:
            sc.logger.info('当前页面主题已全部下载')
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“配乐”按钮')
        sc.driver.find_element_by_name("vivavideo tool preview music n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“点击添加配乐”按钮')
        try:
            sc.driver.find_element_by_name("点击添加配乐").click()
            time.sleep(2)
            sc.capture_screen(fun_name, self.img_path)
        except NoSuchElementException:
            sc.logger.info('当前工程已有配乐，删除后再添加')
            sc.driver.find_element_by_name("vivavideo tool preview delete2").click()
            sc.driver.find_element_by_name("点击添加配乐").click()
            time.sleep(2)
            sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击下载按钮')
        try:
            sc.driver.find_element_by_name('vivavideo material download3 n').click()
        except NoSuchElementException:
            sc.driver.find_element_by_name('music select download n').click()
        sc.capture_screen(fun_name, self.img_path)
        time.sleep(5)

        sc.logger.info('点击第一首已下载音频试听')
        el_music_name = sc.driver.find_element_by_xpath("//*/XCUIElementTypeTable//*/XCUIElementTypeButton[2]")
        try:
            el_music_name.click()
        except NoSuchElementException:
            sc.logger.error('音频下载未完成，继续等待5s')
            time.sleep(5)
            el_music_name.click()

        sc.logger.info('点击“添加”按钮')
        sc.driver.find_element_by_name('添加').click()
        time.sleep(0.5)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('关闭视频原声')
        sc.driver.find_element_by_name("vivavideo tool preview sound n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('关闭配乐')
        sc.driver.find_element_by_name("vivavideo tool grid moremusic ").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('删除配乐')
        sc.driver.find_element_by_name("vivavideo tool preview delete2").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“剪辑”按钮')
        sc.driver.find_element_by_name("vivavideo tool preview edit n").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“小影水印”按钮')
        time.sleep(1)
        try:
            el_watermark = sc.driver.find_element_by_name("vivavideo watermark edit cn n")
            el_watermark.click()
            time.sleep(0.5)
            sc.capture_screen(fun_name, self.img_path)
            sc.driver.find_element_by_name("vivavideo popup close").click()
        except NoSuchElementException:
            sc.logger.info('会员账号已登录，水印已去除')

        sc.logger.info('预览“播放”视频')
        sc.driver.find_element_by_xpath(
            '//XCUIElementTypeButton[@name="vivavideo playerview small whi"]').click()

        sc.logger.info('点击“存草稿”按钮')
        time.sleep(1)
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('返回创作中心主界面')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()