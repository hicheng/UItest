# -*- coding: utf-8 -*-
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from appium.webdriver.common.touch_action import TouchAction
import time


class TestCamera(TestCase):
    """camera测试类."""

    # 获取屏幕尺寸
    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_camera_01_settings(self):
        """拍摄-设置"""
        fun_name = 'test_camera_settings'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('点击高清拍摄')
        try:
            sc.driver.find_element_by_name("高清拍摄").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("拍摄").click()

        # try:
        #     sc.driver.find_element_by_name("跳过").click()
        #     time.sleep(2)
        #     try:
        #         sc.driver.find_element_by_name("高清拍摄").click()
        #     except NoSuchElementException:
        #         sc.driver.find_element_by_name("拍摄").click()
        # except NoSuchElementException:
        #     sc.logger.info('已跳过订阅页面')
        #
        # sc.logger.info("授权小影访问相机和麦克风")
        # try:
        #     sc.driver.find_element_by_name("好").click()  # 授权访问相机
        #     time.sleep(2)
        #     sc.driver.find_element_by_name("好").click()  # 授权访问麦克风
        #     time.sleep(2)
        # except NoSuchElementException:
        #     sc.logger.info("已授权")

        sc.logger.info('点击设置按钮')
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo camera tool icon set").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('闪光灯-开')
        try:
            sc.driver.find_element_by_name("vivavideo camera tool icon fla").click()
        except NoSuchElementException:
            sc.logger.info('当前为后置拍摄，无闪光灯选项')

        sc.logger.info('网格显示')
        sc.driver.find_element_by_name("vivavideo camera tool icon gri").click()

        sc.logger.info('倒计时')
        el_timer = sc.driver.find_element_by_name("vivavideo camera tool icon tim")
        for i in range(4):
            el_timer.click()

        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('退出设置选项')
        sc.driver.find_element_by_name("vivavideo camera tool icon set").click()

        sc.logger.info('前后置切换')
        sc.driver.find_element_by_name("vivavideo camera tool icon cha").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('视频尺寸,全屏切换到3:4')
        el_ful = sc.driver.find_element_by_name("vivavideo camera tool icon ful")
        el_ful.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('视频尺寸,3:4切换到1:1')
        el_fou = sc.driver.find_element_by_name("vivavideo camera tool icon fou")
        el_fou.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('视频尺寸,1:1切换到全屏')
        el_one = sc.driver.find_element_by_name("vivavideo camera tool icon one")
        el_one.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('切换拍摄模式:高清相机->自拍美颜')
        sc.driver.find_element_by_name("自拍美颜").click()
        time.sleep(1)

        sc.logger.info('切换拍摄模式:自拍美颜->高清相机')
        sc.driver.find_element_by_name("高清相机").click()
        time.sleep(1)

        sc.logger.info('切换拍摄模式:高清相机->音乐视频')
        sc.driver.find_element_by_name("音乐视频").click()
        time.sleep(1)

        sc.logger.info('返回创作中心主界面')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo camera tool icon clo").click()

    def test_camera_02_normal(self):
        """拍摄-高清相机(1:1)"""
        fun_name = 'test_normal_shot'

        sc.logger.info('点击高清拍摄')
        try:
            sc.driver.find_element_by_name("高清拍摄").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("拍摄").click()
        time.sleep(1)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('视频尺寸,全屏切换到3:4')
        el_ful = sc.driver.find_element_by_name("vivavideo camera tool icon ful")
        el_ful.click()

        sc.logger.info('视频尺寸,3:4切换到1:1')
        el_fou = sc.driver.find_element_by_name("vivavideo camera tool icon fou")
        el_fou.click()
        sc.capture_screen(fun_name, self.img_path)

        # 点拍
        sc.logger.info('开始录制')
        el_capture = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther[1]")
        el_capture.click()
        time.sleep(5)

        sc.logger.info('录制5s后点击录制按钮停止录制')
        el_capture.click()
        sc.capture_screen(fun_name, self.img_path)

        # 长按拍摄
        sc.logger.info('长按拍摄5s')
        actions = TouchAction(sc.driver)
        actions.long_press(el_capture, None, None, 5000).release().perform()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击确认按钮')
        sc.driver.find_element_by_name("vivavideo camera tool icon nex").click()

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('点击左上角返回按钮退回创作中心')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_camera_03_self(self):
        """拍摄-自拍视频(全屏)"""
        fun_name = 'test_camera_self'

        sc.logger.info('点击“美颜趣拍”')
        sc.driver.find_element_by_name("美颜趣拍").click()
        time.sleep(1)

        sc.logger.info('下载并使用人脸贴纸')
        el_sticker_download = sc.driver.find_element_by_xpath(
            "(//XCUIElementTypeImage[@name='vivavideo_camera_tool_icon_sticker_download_nrm'])[1]")
        el_sticker_download.click()
        sc.capture_screen(fun_name, self.img_path)
        try:
            WebDriverWait(sc.driver, 30).until(
                lambda sticker_download: sticker_download.find_element_by_xpath(
                    "//*/XCUIElementTypeCollectionView[1]//*/XCUIElementTypeOther/XCUIElementTypeImage"))

            sc.logger.info('使用下载的人脸贴纸')
            el_sticker = sc.driver.find_elements_by_xpath(
                "//*/XCUIElementTypeCollectionView[1]//*/XCUIElementTypeOther/XCUIElementTypeImage")
            el_sticker[1].click()
            time.sleep(0.5)
            sc.capture_screen(fun_name, self.img_path)
        except TimeoutError as t:
            sc.logger.error('下载自拍贴纸超时', t)
            return False

        sc.logger.info('切换人脸贴纸分类')
        el_sticker_type = sc.driver.find_elements_by_xpath(
            "//*/XCUIElementTypeCollectionView[2]//*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_sticker_type[1].click()
        time.sleep(0.5)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击屏幕消除贴纸控件')
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()
        time.sleep(0.5)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击滤镜按钮')
        sc.driver.find_element_by_name("vivavideo camera tool icon fil").click()
        time.sleep(0.5)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击屏幕消除滤镜控件')
        actions = TouchAction(sc.driver)
        actions.tap(None, 500, 500, 1).release().perform()
        time.sleep(0.5)
        sc.capture_screen(fun_name, self.img_path)

        # 点拍
        sc.logger.info('开始录制')
        el_capture = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeOther[4]/XCUIElementTypeOther/XCUIElementTypeOther[1]")
        el_capture.click()
        time.sleep(5)

        sc.logger.info('录制5s后点击录制按钮停止录制')
        el_capture.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击确认按钮')
        sc.driver.find_element_by_name("vivavideo camera tool icon nex").click()

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('点击左上角返回按钮退回创作中心')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

    def test_camera_04_music(self):
        """拍摄-音乐视频(3:4)"""
        fun_name = 'test_music_shot'

        sc.logger.info('向左滑动')
        start_x = self.width - self.width // 5
        start_bottom = self.height // 2
        sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.6, 500)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击音乐视频')
        sc.driver.find_element_by_name("音乐视频").click()

        sc.logger.info('切换到3:4拍摄')
        time.sleep(1)
        el_ful = sc.driver.find_element_by_name("vivavideo camera tool icon ful")
        el_ful.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“点击添加配乐”按钮')
        sc.driver.find_element_by_name("点击添加配乐").click()
        time.sleep(2)

        sc.logger.info('点击下载按钮')
        try:
            sc.driver.find_element_by_name('vivavideo material download3 n').click()
        except NoSuchElementException:
            sc.driver.find_element_by_name('music select download n').click()
        sc.capture_screen(fun_name, self.img_path)
        time.sleep(10)

        sc.logger.info('点击第一首已下载音频试听')
        el_music_name = sc.driver.find_element_by_xpath("//*/XCUIElementTypeTable//*/XCUIElementTypeButton[2]")
        try:
            el_music_name.click()
        except NoSuchElementException:
            sc.logger.error('音频下载未完成，继续等待5s')
            time.sleep(5)
            el_music_name.click()

        sc.logger.info('点击“添加”按钮')
        sc.driver.find_element_by_name('添加').click()

        sc.logger.info('开始录制')
        # 点拍5s
        el_capture = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeOther[5]/XCUIElementTypeOther/XCUIElementTypeOther[1]")
        el_capture.click()
        time.sleep(5)
        sc.logger.info('拍摄5s后点击录制按钮停止拍摄')
        el_capture.click()

        sc.logger.info('点击音乐标题')
        time.sleep(1)
        sc.driver.find_element_by_accessibility_id("vivavideo_camera_tool_icon_music_nrm").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('更换音乐重录')
        sc.driver.find_element_by_name("更换音乐重录").click()

        sc.logger.info('取消重录')
        sc.driver.find_element_by_name("music select back n").click()

        sc.logger.info('点击音乐标题')
        time.sleep(.500)
        sc.driver.find_element_by_accessibility_id("vivavideo_camera_tool_icon_music_nrm").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"直接重录"')
        time.sleep(1)
        sc.driver.find_element_by_name("直接重录").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('开始录制')
        # 点拍5s
        el_capture = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeOther[5]/XCUIElementTypeOther/XCUIElementTypeOther[1]")
        el_capture.click()
        time.sleep(5)
        sc.logger.info('拍摄5s后点击录制按钮停止拍摄')
        el_capture.click()

        sc.logger.info('录制完成，进入预览页')
        try:
            sc.logger.info('点击确认按钮')
            sc.driver.find_element_by_name("vivavideo camera tool icon nex").click()
        except NoSuchElementException:
            sc.logger.info('音乐时长较短，已自动跳转预览页')

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('点击左上角返回按钮退回创作中心')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

