# -*- coding: utf-8 -*-
import time
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait



class TestPersonal(TestCase):
    """个人中心测试类."""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_personal(self):
        """个人空间详情页"""
        sc.logger.info('个人空间详情页')
        fun_name = 'test_personal'
        start_x = self.width // 2
        start_y = self.height // 8
        start_bottom = self.height - start_y

        sc.logger.info('切换到"我"')
        btn_me = "//*/XCUIElementTypeTabBar/XCUIElementTypeButton[3]"
        sc.driver.find_element_by_xpath(btn_me).click()

        sc.logger.info('切换到作品tab')
        el_video = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '作品'")
        el_video.click()

        sc.logger.info('下拉刷新')
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.300)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('向上滑动2次')
        for i in range(2):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('切换到粉丝tab')
        el_fan = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '粉丝'")
        el_fan.click()

        sc.logger.info('向上滑动2次')
        for i in range(2):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('切换到关注tab')
        el_focus = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '关注'")
        el_focus.click()

        sc.logger.info('下拉刷新')
        sc.swipe_by_ratio(start_x, start_y, 'down', 0.3, 300)
        time.sleep(.500)

        sc.logger.info('点击其他用户头像')
        el_avatar = sc.driver.find_element_by_xpath(
            '//*/XCUIElementTypeWindow[1]//*/XCUIElementTypeTable/*/XCUIElementTypeButton')
        el_avatar.click()

        sc.logger.info('等待完全跳转他人个人页')
        time.sleep(2)

        sc.logger.info('切换到作品tab')
        el_video = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '作品'")
        el_video.click()

        sc.logger.info('向上滑动2次')
        for i in range(2):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('切换到粉丝tab')
        el_fan = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '粉丝'")
        el_fan.click()

        sc.logger.info('向上滑动2次')
        for i in range(2):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)

        sc.logger.info('切换到关注tab')
        el_focus = sc.driver.find_elements_by_ios_predicate(
            "type == 'XCUIElementTypeButton' AND label CONTAINS '关注'")

        for i in range(len(el_focus)):
            el_focus[i].click()
            try:
                sc.driver.find_element_by_name('取消').click()
            except NoSuchElementException:
                sc.logger.info('点击的不是"已关注/关注按钮"，切换到该用户的关注列表')

        sc.logger.info('向上滑动2次')
        for i in range(2):
            sc.logger.info('第 %d 次上滑动', i)
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.7, 300)
            time.sleep(.300)