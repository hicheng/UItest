# -*- coding: utf-8 -*-
"""创作页面素材中心的测试用例."""
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from unittest import TestCase
from iOS import script_ultils as sc


class TestTemplate(TestCase):
    """素材中心测试类."""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    @classmethod
    def template_manager(cls, type, el_delete):
        """主题管理."""
        sc.logger.info('%s删除测试', type)
        fun_name = 'theme_manager'

        sc.logger.info('再次进入素材中心并点击对应素材分类')
        sc.driver.find_element_by_name("素材中心").click()
        sc.driver.find_element_by_name(type).click()

        sc.logger.info('点击管理按钮')
        sc.driver.find_element_by_name("vivavideo material Management ").click()
        sc.capture_screen(fun_name, cls.img_path)

        el_template_del = sc.driver.find_element_by_name(el_delete)
        el_template_del.click()
        try:
            sc.driver.find_element_by_name("确认").click()
        except NoSuchElementException:
            sc.logger.info('%s删除不需要确认', type)
        sc.capture_screen(fun_name, cls.img_path)

        sc.logger.info('删除完成后，返回创作中心页面')
        el_back = sc.driver.find_element_by_name("vivavideo com nav back n")
        for i in range(2):
            time.sleep(.500)
            el_back.click()

    def test_template_theme(self):
        """素材中心-主题"""
        sc.logger.info('进入素材中心-主题')
        fun_name = 'test_template_theme'

        start_x = self.width - self.width // 5
        start_bottom = self.height // 2

        sc.logger.info('点击"素材中心"')
        try:
            sc.driver.find_element_by_name("素材中心").click()
        except NoSuchElementException:
            sc.logger.info('"素材中心"在第二页，需要向左滑动')
            sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.6, 500)
            sc.driver.find_element_by_name("素材中心").click()

        sc.logger.info('点击“主题”')
        sc.driver.find_element_by_name("主题").click()
        time.sleep(1.5)

        sc.logger.info('开始下载主题')
        try:
            sc.logger.info('点击“下载”按钮')
            sc.driver.find_element_by_name("vivavideo material download n").click()
            time.sleep(5)
        except NoSuchElementException:
            sc.logger.info('当前页面所有素材已下载完成')
            return True

        sc.logger.info('点击“使用”按钮')
        try:
            sc.driver.find_element_by_name("使用").click()
        except NoSuchElementException:
            sc.logger.info('下载未完成，继续等待5s')
            time.sleep(5)
            sc.driver.find_element_by_name("使用").click()

        sc.logger.info('添加视频')
        time.sleep(1)
        el_video = sc.driver.find_element_by_accessibility_id("vivavideo_tool_gallery_audio_type_video")
        el_video.click()
        sc.driver.find_element_by_name("添加 0").click()

        sc.logger.info('添加图片')
        sc.driver.find_element_by_name("视频").click()
        sc.driver.find_element_by_name("图片").click()
        el_img = sc.driver.find_elements_by_xpath("//*/XCUIElementTypeImage")
        el_img[1].click()

        sc.logger.info('点击"下一步"')
        sc.driver.find_element_by_name("下一步").click()

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_name("存草稿").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击左上角返回按钮退回创作中心')
        time.sleep(1)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

        sc.logger.info('删除下载的主题')
        btn_del = 'vivavideo material delete n'
        self.template_manager('主题', btn_del)

    def test_template_text(self):
        """素材中心-字幕"""
        sc.logger.info('素材中心-字幕')
        fun_name = 'test_template_text'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_n']").click()
        except NoSuchElementException:
            sc.driver.find_element_by_xpath("//XCUIElementTypeImage[@name='camerta_f']").click()

        start_x = self.width - self.width // 5
        start_bottom = self.height // 2

        sc.logger.info('点击"素材中心"')
        try:
            sc.driver.find_element_by_name("素材中心").click()
        except NoSuchElementException:
            sc.logger.info('"素材中心"在第二页，需要向左滑动')
            sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.6, 500)
            sc.driver.find_element_by_name("素材中心").click()

        sc.logger.info('点击"字幕"')
        time.sleep(.500)
        sc.driver.find_element_by_name("字幕").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('下载“字幕”')
        try:
            sc.logger.info('点击“下载”按钮')
            sc.driver.find_element_by_name('vivavideo material download n').click()
            time.sleep(5)
        except NoSuchElementException:
            sc.logger.info('当前页面所有素材已下载完成')
            return True

        sc.logger.info('点击“使用”按钮')
        try:
            sc.driver.find_element_by_name("使用").click()
        except NoSuchElementException:
            sc.logger.info('下载未完成，继续等待5s')
            time.sleep(5)
            sc.driver.find_element_by_name("使用").click()

        sc.logger.info('添加视频')
        time.sleep(1)
        el_video = sc.driver.find_element_by_accessibility_id("vivavideo_tool_gallery_audio_type_video")
        el_video.click()
        sc.driver.find_element_by_name("添加 0").click()

        sc.logger.info('添加图片')
        sc.driver.find_element_by_name("视频").click()
        sc.driver.find_element_by_name("图片").click()
        el_img = sc.driver.find_elements_by_xpath("//*/XCUIElementTypeImage")
        el_img[1].click()

        sc.logger.info('点击"下一步"')
        sc.driver.find_element_by_name("下一步").click()

        sc.logger.info('点击右上角保存')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击左侧"暂停"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar paus").click()

        sc.logger.info('点击底部"确认"按钮')
        sc.driver.find_element_by_name("vivavideo editor framebar comp").click()

        sc.logger.info('保存使用的字幕')
        sc.driver.find_element_by_name("vivavideo editor common ok").click()

        sc.logger.info('点击“存草稿”按钮')
        time.sleep(.500)
        sc.driver.find_element_by_name("存草稿").click()

        sc.logger.info('点击左上角返回按钮退回创作中心')
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo com nav back n").click()

        sc.logger.info('删除下载的字幕')
        btn_del = 'vivavideo material delete n'
        self.template_manager('字幕', btn_del)