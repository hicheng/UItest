# -*- coding: utf-8 -*-
"""发布页面内分享相关的测试用例."""
import time
from unittest import TestCase
from iOS import script_ultils as sc
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait


class TestPublish(TestCase):
    """视频发布测试类"""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_publish(self):
        """视频发布"""
        sc.logger.info('视频发布')
        fun_name = 'test_publish'

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('进入我的工作室')
        sc.driver.find_element_by_name("更多草稿").click()
        time.sleep(.500)

        sc.logger.info('保存并上传')
        el_publish = sc.driver.find_element_by_name("保存/上传")
        el_publish.click()

        sc.logger.info('清空标题')
        el_title_clear = sc.driver.find_element_by_xpath("//*/XCUIElementTypeScrollView/XCUIElementTypeTextView")
        el_title_clear.clear()

        sc.logger.info('空标题发布')
        sc.driver.find_element_by_name("保存/上传").click()
        time.sleep(1)

        sc.logger.info('关闭定位服务')
        try:
            sc.driver.find_element_by_xpath(
                '//XCUIElementTypeButton[@name="icon not box n"]').click()
        except NoSuchElementException:
            sc.logger.info('不是第一次点击保存/上传按钮')

        sc.logger.info('输入标题')
        time.sleep(.500)
        el_title = sc.driver.find_element_by_xpath('//XCUIElementTypeStaticText[@name="请输入标题，你的作品记录了什么？"]')
        el_title.clear()
        el_title.send_keys('input video title test')
        time.sleep(1)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('输入描述')
        el_des = sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther[1]/XCUIElementTypeTextView")
        el_des.clear()
        el_des.send_keys("input description text")
        time.sleep(.500)
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeButton[@name='Done']").click()
        except NoSuchElementException:
            sc.logger.info("当前键盘为中文键盘")
            sc.driver.find_element_by_xpath("完成").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击"更换封面"')
        sc.driver.find_element_by_name("更换封面").click()
        time.sleep(3)

        sc.logger.info('点击"动画贴纸"图标')
        sc.driver.find_element_by_name("动画贴纸").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('添加一个贴纸')
        el_sticker_select = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView[2]/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_sticker_select.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('保存已添加的封面贴纸')
        sc.driver.find_element_by_name("xiaoying itembar finish").click()
        time.sleep(.500)

        sc.logger.info('点击"字幕"按钮')
        sc.driver.find_element_by_name("字幕").click()

        sc.logger.info('添加一个字幕')
        el_text_select = sc.driver.find_element_by_xpath(
            "//*/XCUIElementTypeCollectionView[2]/*/XCUIElementTypeOther/XCUIElementTypeImage")
        el_text_select.click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('编辑字幕')
        sc.driver.find_element_by_xpath("//*/XCUIElementTypeOther/XCUIElementTypeImage[2]").click()

        sc.logger.info('输入字幕')
        el_text_input = sc.driver.find_element_by_ios_predicate(
            "type == 'XCUIElementTypeTextView' AND value == '点击输入字幕…'")
        el_text_input.clear()
        el_text_input.send_keys("input text test")

        sc.logger.info('保存输入的字幕')
        try:
            sc.driver.find_element_by_xpath("//XCUIElementTypeButton[@name='Done']").click()
        except NoSuchElementException:
            sc.logger.info("当前键盘为中文键盘")
            sc.driver.find_element_by_xpath("完成").click()

        sc.logger.info('点击"字体"按钮')
        time.sleep(1)
        sc.driver.find_element_by_name("字体").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('下载任意"字体"')
        el_text_download = sc.driver.find_element_by_accessibility_id("vivavideo_camera_tool_icon_sticker_download_nrm")
        try:
            el_text_download.click()
        except NoSuchElementException:
            sc.logger.info('当前页面已无为下载"字体"')

        sc.logger.info('保存已添加的封面字幕')
        sc.driver.find_element_by_name("xiaoying itembar finish").click()
        time.sleep(.500)
        sc.driver.find_element_by_name("vivavideo editor common ok").click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('添加话题')
        try:
            sc.driver.find_element_by_xpath(
                '//XCUIElementTypeButton[@name=" 添加话题"]').click()
            sc.logger.info('添加一个推荐话题')
            el_topic = sc.driver.find_element_by_ios_predicate("type == 'XCUIElementTypeCell'")
            el_topic.click()
            sc.capture_screen(fun_name,self.img_path)
        except Exception as e:
            sc.logger.error('获取不到添加话题控件',e)

        sc.logger.info('显示位置')
        try:
            sc.driver.find_element_by_xpath(
                '//XCUIElementTypeButton[@name=" 显示位置"]').click()
            sc.driver.find_element_by_name('取消')
        except Exception as e:
            sc.logger.error('获取不到显示位置控件',e)

        sc.logger.info('点击"隐私设置"')
        sc.driver.find_element_by_name("隐私设置").click()

        sc.logger.info('设置"隐私设置"')
        el_privacy = sc.driver.find_elements_by_ios_predicate("type == 'XCUIElementTypeSwitch'")
        for i in range(len(el_privacy)):
            el_privacy[i].click()
            sc.capture_screen(fun_name, self.img_path)
            try:
                sc.driver.find_element_by_name("我知道了").click()
            except NoSuchElementException:
                sc.logger.info('不是第一次设置，无设置提示')

        sc.logger.info('保存"隐私设置"')
        sc.driver.find_element_by_name("完成").click()

        sc.logger.info('发布')
        sc.driver.find_element_by_name("保存/上传").click()

        sc.logger.info('选择480P导出')
        sc.driver.find_element_by_name("清晰 480P").click()

        sc.logger.info('开始导出并上传')
        try:
            WebDriverWait(sc.driver, 60).until(
                lambda V_exprot: V_exprot.find_element_by_name('发现'))
            sc.capture_screen(fun_name, self.img_path)

            sc.logger.info('点击"我"查看发布的视频')
            sc.driver.find_element_by_name("我").click()  # 个人页
            time.sleep(2)
            sc.capture_screen(fun_name, self.img_path)
        except Exception as e:
            sc.logger.error('发布失败', e)
            return False