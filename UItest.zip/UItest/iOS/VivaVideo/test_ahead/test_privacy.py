# -*- coding: utf-8 -*-
from unittest import TestCase
from iOS import script_ultils as sc
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait


class TestPrivacy(TestCase):
    """权限获取测试类."""

    # 获取屏幕尺寸
    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def setUpClass(cls):
        sc.driver.launch_app()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        sc.driver.close_app()

    def test_Privacy(self):
        """权限获取"""

        sc.logger.info('点击创作中心主按钮')
        try:
            sc.driver.find_element_by_accessibility_id("camerta_n").click()
        except NoSuchElementException:
            sc.driver.find_element_by_accessibility_id("camerta_f").click()

        sc.logger.info('点击视频剪辑')
        try:
            sc.driver.find_element_by_name("视频剪辑").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("剪辑").click()

        time.sleep(.500)

        try:
            sc.driver.find_element_by_name("跳过").click()
            time.sleep(1)
            try:
                sc.driver.find_element_by_name("视频剪辑").click()
            except NoSuchElementException:
                sc.driver.find_element_by_name("剪辑").click()
        except NoSuchElementException:
            sc.logger.info('已跳过订阅页面')

        sc.logger.info("授权小影访问相册和媒体资料")
        try:
            sc.driver.find_element_by_name("好").click() #授权相册
            time.sleep(1)
            sc.driver.find_element_by_name("好").click() #授权媒体资料库
            time.sleep(1)
        except NoSuchElementException:
            sc.logger.info("已授权")

        sc.logger.info('返回首页')
        sc.driver.find_element_by_name("vivavideo gallery back n").click()

        sc.logger.info('点击高清拍摄')
        try:
            sc.driver.find_element_by_name("高清拍摄").click()
        except NoSuchElementException:
            sc.driver.find_element_by_name("拍摄").click()
        time.sleep(.500)

        sc.logger.info("授权小影访问相机和麦克风")
        try:
            sc.driver.find_element_by_name("好").click()  # 授权访问相机
            time.sleep(1)
            sc.driver.find_element_by_name("好").click()  # 授权访问麦克风
            time.sleep(1)
        except NoSuchElementException:
            sc.logger.info("已授权")










