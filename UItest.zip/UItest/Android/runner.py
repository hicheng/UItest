#coding=utf-8
import os
import time
import unittest
from Android import script_ultils as sc, HTMLTestRunner


def run_test():
    # 用例路径
    sc_path = os.path.join(os.getcwd(), "VivaVideo/test_creations/test_camera")

    suite1 = unittest.TestLoader().discover(sc_path,pattern="*.py", top_level_dir=None)

    suite = unittest.TestSuite(suite1)
    return suite

if __name__ == '__main__':
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxx Start Test xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    now_time = time.strftime("%Y%m%d%H%M", time.localtime(time.time()))
    report_path = sc.path_lists[2]
    filename = report_path + now_time + ".html"
    fp = open(filename, 'wb+')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title='VivaVideo UI 测试结果',
        description='详细测试报告',
    )
    runner.run(run_test())
    fp.close()
    print("xxxxxxxxxxxxxxxxxxxxxxxxx Finish Test xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")