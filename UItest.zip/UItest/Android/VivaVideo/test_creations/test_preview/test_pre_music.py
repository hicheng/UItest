# -*- coding: utf-8 -*-
"""预览页面的music测试用例."""
import time

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from appium.webdriver.common.touch_action import TouchAction
from Android import script_ultils as sc


class TestPreviewMusic(object):
    """预览页面的music测试类."""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    def test_music_create(self):
        """导出-创建视频."""
        sc.logger.info('分享-创建视频')
        fun_name = 'test_music_create'

        sc.logger.info('点击创作中心主按钮')
        c_btn = 'com.quvideo.xiaoying:id/img_creation'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(c_btn)).click()

        sc.logger.info('点击“拍摄”')
        sc.driver.find_element_by_id('com.quvideo.xiaoying:id/icon2').click()

        el_cp = sc.driver.find_element_by_id('com.quvideo.xiaoying:id/btn_rec')

        # 长按拍摄
        sc.logger.info('长按拍摄5s')
        actions = TouchAction(sc.driver)
        actions.long_press(el_cp, None, None, 5000).release().perform()
        sc.capture_screen(fun_name, self.img_path)

        next_btn = 'com.quvideo.xiaoying:id/cam_btn_next'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_id(next_btn)).click()

        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_android_uiautomator(
                'text("存草稿")')).click()

        sc.capture_screen(fun_name, self.img_path)
        sc.logger.info('分享-创建视频完成')

    def test_music_add(self):
        """预览页-配乐."""
        sc.logger.info('预览页-配乐')
        fun_name = 'test_music_add'

        sc.logger.info('点击草稿封面')
        draft_img = 'com.quvideo.xiaoying:id/xiaoying_studio_img_project_thumb'
        sc.driver.find_element_by_id(draft_img).click()

        sc.logger.info('点击“配乐”')
        sc.driver.find_element_by_android_uiautomator('text("配乐")').click()
        sc.capture_screen(fun_name, self.img_path)
        sc.logger.info('点击添加配乐')
        bgm_row = 'com.quvideo.xiaoying:id/txtview_bgm_name'
        sc.driver.find_element_by_id(bgm_row).click()

        sc.logger.info('下载音乐')
        music_item_download = 'com.quvideo.xiaoying:id/music_item_download'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(music_item_download)).click()

        sc.logger.info('添加音乐')
        music_item_name = 'com.quvideo.xiaoying:id/music_item_name'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(music_item_name)).click()

        while True:
            try:
                state_btn = 'com.quvideo.xiaoying:id/music_item_play_state'
                WebDriverWait(sc.driver, 10, 1).until(
                    lambda el: el.find_element_by_id(state_btn)).click()
                sc.logger.info('点击播放状态')
                break
            except TimeoutException:
                time.sleep(5)
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('使用音乐')
        use_btn = 'com.quvideo.xiaoying:id/music_item_use'
        sc.driver.find_element_by_id(use_btn).click()

        fake_layout = 'com.quvideo.xiaoying:id/preview_layout_fake'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(fake_layout)).click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击声音按钮')
        video_icon = 'com.quvideo.xiaoying:id/imgview_icon_video'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(video_icon)).click()

        sc.logger.info('点击音乐按钮')
        bgm_icon = 'com.quvideo.xiaoying:id/imgview_icon_bgm'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(bgm_icon)).click()

        sc.logger.info('点击删除音乐按钮')
        del_icon = 'com.quvideo.xiaoying:id/imgbtn_del_music'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(del_icon)).click()
        sc.capture_screen(fun_name, self.img_path)
        sc.logger.info('预览页-配乐测试完成')
