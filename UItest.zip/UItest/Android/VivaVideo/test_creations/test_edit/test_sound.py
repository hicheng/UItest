# -*- coding: utf-8 -*-
"""配音的基本操作测试用例."""
import time

from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from appium.webdriver.common.touch_action import TouchAction
from Android import script_ultils as sc


class TestEditSound(object):
    """配音的基本操作测试类."""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    def test_edit_sound_add(self):
        """剪辑-配音-添加."""
        sc.logger.info('剪辑-配音-添加')
        fun_name = 'test_edit_sound_add'

        start_x = self.width - self.width // 4
        start_bottom = self.height - self.height // 10

        sc.logger.info('点击创作中心主按钮')
        c_btn = 'com.quvideo.xiaoying:id/img_creation'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(c_btn)).click()

        sc.logger.info('点击“更多草稿”')
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_android_uiautomator(
                'text("更多草稿")')).click()

        sc.logger.info('点击草稿封面')
        draft_img = 'com.quvideo.xiaoying:id/xiaoying_studio_img_project_thumb'
        sc.driver.find_element_by_id(draft_img).click()
        sc.logger.info('点击“剪辑”')
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_android_uiautomator(
                'text("剪辑")')).click()

        time.sleep(1)
        sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.6, 500)
        t_list = sc.driver.find_elements_by_id('com.quvideo.xiaoying:id/title')
        for el_item in t_list:
            if el_item.text == '配音':
                sc.logger.info('开始点击配音')
                el_item.click()
                break

        record_btn = 'com.quvideo.xiaoying:id/dub_panel_audio_record_btn'
        try:
            WebDriverWait(sc.driver, 10, 1).until(
                lambda c_btn: c_btn.find_element_by_id(record_btn))
            el_record = sc.driver.find_element_by_id(record_btn)
        except TimeoutException:
            speed_close_btn = 'com.quvideo.xiaoying:id/imgbtn_speed_close'
            WebDriverWait(sc.driver, 10, 1).until(
                lambda el: el.find_element_by_id(speed_close_btn)).click()

            del_dub_btn = 'com.quvideo.xiaoying:id/imgbtn_del_dub'
            WebDriverWait(sc.driver, 10, 1).until(
                lambda c_btn: c_btn.find_element_by_id(del_dub_btn)).click()

            record_btn = 'com.quvideo.xiaoying:id/dub_panel_audio_record_btn'
            WebDriverWait(sc.driver, 10, 1).until(
                lambda c_btn: c_btn.find_element_by_id(record_btn))
            el_record = sc.driver.find_element_by_id(record_btn)

        # 长按录制
        sc.logger.info('长按录制5s')
        actions = TouchAction(sc.driver)
        actions.long_press(el_record, None, None, 5000).release().perform()
        sc.capture_screen(fun_name, self.img_path)

        """
        x = record.location.get('x')
        y = record.location.get('y')
        sc.driver.swipe(x, y, x, y, 5000)

        sc.logger.info('点击添加音频的按钮')
        au_add_btn = 'com.quvideo.xiaoying:id/xiaoying_ve_imgbtn_add_audio_dub'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(au_add_btn)).click()

        music_row = 'com.quvideo.xiaoying:id/musiclist_title'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_id(music_row)).click()

        music_add_btn = 'com.quvideo.xiaoying:id/btn_add_music'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_id(music_add_btn)).click()
        """

        right_btn = 'com.quvideo.xiaoying:id/xiaoying_com_btn_right'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_id(right_btn)).click()

        sc.logger.info('返回创作中心主界面')
        for i in range(3):
            time.sleep(2)
            sc.driver.press_keycode(4)
        sc.logger.info('剪辑-配音-添加测试完成')

    def test_edit_sound_del(self):
        """剪辑-配音-删除."""
        sc.logger.info('剪辑-配音-删除')
        fun_name = 'test_edit_sound_del'

        start_x = self.width - self.width // 4
        start_bottom = self.height - self.height // 10

        sc.logger.info('点击创作中心主按钮')
        c_btn = 'com.quvideo.xiaoying:id/img_creation'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(c_btn)).click()
        # sc.driver.find_element_by_id('com.quvideo.xiaoying:id/img_creation').click()

        sc.logger.info('点击“更多草稿”')
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_android_uiautomator(
                'text("更多草稿")')).click()

        sc.logger.info('点击草稿封面')
        draft_img = 'com.quvideo.xiaoying:id/xiaoying_studio_img_project_thumb'
        sc.driver.find_element_by_id(draft_img).click()

        sc.logger.info('点击“剪辑”')
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_android_uiautomator(
                'text("剪辑")')).click()

        time.sleep(1)
        sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.6, 500)
        t_list = sc.driver.find_elements_by_id('com.quvideo.xiaoying:id/title')
        for el_item in t_list:
            if el_item.text == '配音':
                sc.logger.info('开始点击配音')
                el_item.click()
                break

        speed_close_btn = 'com.quvideo.xiaoying:id/imgbtn_speed_close'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_id(speed_close_btn)).click()

        del_btn = 'com.quvideo.xiaoying:id/imgbtn_del_dub'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_id(del_btn)).click()

        right_btn = 'com.quvideo.xiaoying:id/xiaoying_com_btn_right'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda c_btn: c_btn.find_element_by_id(right_btn)).click()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('返回创作中心主界面')
        for i in range(3):
            time.sleep(2)
            sc.driver.press_keycode(4)
        sc.logger.info('剪辑-配音-删除测试完成')
