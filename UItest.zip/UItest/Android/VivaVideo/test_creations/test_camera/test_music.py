# -*- coding: utf-8 -*-
"""camera音乐视频的基本操作测试用例."""
import time

from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from appium.webdriver.common.touch_action import TouchAction
from Android import script_ultils as sc


class TestCameraMusic(object):
    """camera音乐视频的基本测试类."""

    width, height = sc.get_size()
    img_path = sc.path_lists[0]
    c_btn = 'com.quvideo.xiaoying:id/img_creation'

    def test_music_shot(self):
        """拍摄-音乐视频(3:4)."""
        sc.logger.info('拍摄-音乐视频(3:4)')
        fun_name = 'test_music_shot'
        start_x = self.width - self.width // 10
        start_bottom = self.height // 2

        sc.logger.info('点击创作中心主按钮')
        sc.first_step(self.c_btn)

        time.sleep(2)
        sc.swipe_by_ratio(start_x, start_bottom, 'left', 0.8, 500)
        sc.logger.info('点击“音乐视频”')
        WebDriverWait(sc.driver, 5, 1).until(
            lambda el: el.find_element_by_android_uiautomator(
                'text("音乐视频")')).click()
        # sc.driver.find_element_by_android_uiautomator('text("音乐视频")').click()
        time.sleep(1)
        sc.logger.info('点击视频比例按钮，切换到3:4')
        ratio_btn = 'com.quvideo.xiaoying:id/cam_btn_ratio'
        sc.driver.find_element_by_id(ratio_btn).click()

        sc.logger.info('切换摄像头')
        switch_btn = 'com.quvideo.xiaoying:id/img_switch'
        sc.driver.find_element_by_id(switch_btn).click()

        time.sleep(2)
        sc.logger.info('点击“请选择音乐”按钮')
        sc.driver.find_element_by_android_uiautomator('text("请选择音乐")').click()
        time.sleep(2)

        download_btn = 'com.quvideo.xiaoying:id/music_item_download'
        try:
            el_download = sc.driver.find_element_by_id(download_btn)
        except NoSuchElementException:
            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.4, 500)
            el_download = sc.driver.find_element_by_id(download_btn)
        sc.logger.info('点击第一个下载按钮')
        el_download.click()

        time.sleep(5)
        music_row = 'com.quvideo.xiaoying:id/music_item_name'
        el_music_name = sc.driver.find_element_by_id(music_row)
        sc.logger.info('点击第一首音乐名')
        el_music_name.click()
        sc.logger.info('点击播放/暂停按钮')
        play_btn = 'com.quvideo.xiaoying:id/music_item_play_state'
        sc.driver.find_element_by_id(play_btn).click()

        sc.logger.info('点击“添加”按钮')
        use_btn = 'com.quvideo.xiaoying:id/music_item_use'
        sc.driver.find_element_by_id(use_btn).click()
        el_cp = sc.driver.find_element_by_id('com.quvideo.xiaoying:id/btn_rec')

        # 长按拍摄5s
        sc.logger.info('长按拍摄5s')
        actions = TouchAction(sc.driver)
        actions.long_press(el_cp, None, None, 5000).release().perform()
        sc.capture_screen(fun_name, self.img_path)
        try:
            sc.logger.info('点击确认按钮')
            n_btn = 'com.quvideo.xiaoying:id/cam_btn_next'
            WebDriverWait(sc.driver, 10, 1).until(
                lambda el: el.find_element_by_id(n_btn)).click()
        except TimeoutException:
            sc.logger.info('音乐时长较短，已自动跳转预览页')
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击“存草稿”按钮')
        sc.driver.find_element_by_android_uiautomator('text("存草稿")').click()

        left_btn = 'com.quvideo.xiaoying:id/xiaoying_com_btn_left'
        sc.driver.find_element_by_id(left_btn).click()
        sc.logger.info('拍摄-音乐视频(3:4)完成')
