# -*- coding: utf-8 -*-
"""创作页面内导出视频相关的测试用例."""
import time

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from appium.webdriver.common.touch_action import TouchAction
from Android import script_ultils as sc


class TestCreationExport(object):
    """
    创作页面内导出视频相关的测试类.

    1.执行导出用例时，请确认当前app未进行过导出操作
    2.使用已购买会员账号登录
    """

    width, height = sc.get_size()
    img_path = sc.path_lists[0]

    @classmethod
    def hardware_acceleration(cls):
        """硬件加速设置."""
        try:
            sc.logger.info('尝试开启硬件加速')
            WebDriverWait(sc.driver, 5, 1).until(
                lambda el: el.find_element_by_android_uiautomator(
                    'text("视频处理硬件加速")')).click()
        except TimeoutException:
            sc.logger.info('未找到硬件加速选项，上滑半屏尝试')
            start_x = cls.width // 2
            start_y = cls.height // 8
            start_bottom = cls.height - start_y

            sc.swipe_by_ratio(start_x, start_bottom, 'up', 0.4, 600)
            WebDriverWait(sc.driver, 5, 1).until(
                lambda el: el.find_element_by_android_uiautomator(
                    'text("视频处理硬件加速")')).click()
        time.sleep(1)
        sc.driver.press_keycode(4)

    def test_export_create(self):
        """导出-创建视频."""
        sc.logger.info('导出-创建视频')
        fun_name = 'test_export_create'

        sc.logger.info('点击创作中心主按钮')
        c_btn = 'com.quvideo.xiaoying:id/img_creation'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(c_btn)).click()

        sc.logger.info('点击“拍摄”')
        sc.driver.find_element_by_id('com.quvideo.xiaoying:id/icon2').click()

        sc.logger.info('点击录制按钮')
        el_cp = sc.driver.find_element_by_id('com.quvideo.xiaoying:id/btn_rec')

        # 长按拍摄
        sc.logger.info('长按拍摄5s')
        actions = TouchAction(sc.driver)
        actions.long_press(el_cp, None, None, 5000).release().perform()
        sc.capture_screen(fun_name, self.img_path)

        sc.logger.info('点击确认按钮')
        time.sleep(1)
        next_btn = 'com.quvideo.xiaoying:id/cam_btn_next'
        sc.driver.find_element_by_id(next_btn).click()
        sc.capture_screen(fun_name, self.img_path)

        sc.driver.find_element_by_android_uiautomator('text("保存/上传")').click()
        sc.logger.info('导出-创建视频完成')

    def test_export_first(self):
        """导出-保存到相册-480P-首次导出."""
        sc.logger.info('导出-保存到相册-480P-首次导出')
        fun_name = 'test_export_first'

        sc.logger.info('点击“保存到相册”')
        export_btn = 'com.quvideo.xiaoying:id/btn_export'
        WebDriverWait(sc.driver, 10, 1).until(
            lambda el: el.find_element_by_id(export_btn)).click()
        # sc.driver.find_element_by_id('com.quvideo.xiaoying:id/btn_export').click()

        try:
            pos_btn = 'com.quvideo.xiaoying:id/buttonDefaultPositive'
            WebDriverWait(sc.driver, 5, 1).until(
                lambda el: el.find_element_by_id(pos_btn)).click()
            TestCreationExport.hardware_acceleration()

            WebDriverWait(sc.driver, 10, 1).until(
                lambda el: el.find_element_by_id(export_btn)).click()
        except TimeoutException:
            sc.logger.info('无需设置硬件加速')

        sc.logger.info('点击“480P 清晰”')
        limit_btn = 'com.quvideo.xiaoying:id/normal_layout'
        WebDriverWait(sc.driver, 5, 1).until(
            lambda el: el.find_element_by_id(limit_btn)).click()
        try:
            WebDriverWait(sc.driver, 30).until(
                lambda x: x.find_element_by_android_uiautomator('text("工作室")'))
            sc.capture_screen(fun_name, self.img_path)
        except TimeoutException:
            sc.driver.press_keycode(4)
        time.sleep(2)
        sc.driver.press_keycode(4)
        sc.logger.info('导出-保存到相册-480P-首次导出测试完成')
