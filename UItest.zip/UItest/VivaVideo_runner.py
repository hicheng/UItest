#coding=utf-8
import os
import time
import unittest
from iOS import script_ultils as sc, HTMLTestRunner
from iOS.start_appium import myserver


def run_test():
    # 用例路径
    sc_path1 = os.path.join(os.getcwd(), "iOS/VivaVideo/test_ahead")
    sc_path2 = os.path.join(os.getcwd(), "iOS/VivaVideo/test_creations")

    suite1 = unittest.TestLoader().discover(sc_path1,pattern="*.py", top_level_dir=None)
    suite2 = unittest.TestLoader().discover(sc_path2, pattern="*.py", top_level_dir=None)

    suite = unittest.TestSuite([suite1,suite2])
    return suite

if __name__ == '__main__':
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxx Start Test xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    now_time = time.strftime("%Y%m%d%H%M", time.localtime(time.time()))
    report_path = sc.path_lists[2]
    filename = report_path + now_time + ".html"
    fp = open(filename, 'wb+')
    runner = HTMLTestRunner.HTMLTestRunner(
        stream=fp,
        title='VivaVideo UI（iOS） 测试结果',
        description='详细测试报告',
        verbosity = 2

    )
    runner.run(run_test())
    fp.close()
    print("xxxxxxxxxxxxxxxxxxxxxxxxx Finish Test xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")